﻿namespace Project3a
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.aboutDescription = new System.Windows.Forms.TextBox();
            this.authorInfo = new System.Windows.Forms.Label();
            this.getPeople = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "About Description";
            // 
            // aboutDescription
            // 
            this.aboutDescription.Location = new System.Drawing.Point(111, 13);
            this.aboutDescription.Name = "aboutDescription";
            this.aboutDescription.Size = new System.Drawing.Size(452, 20);
            this.aboutDescription.TabIndex = 1;
            // 
            // authorInfo
            // 
            this.authorInfo.AutoSize = true;
            this.authorInfo.Location = new System.Drawing.Point(13, 42);
            this.authorInfo.Name = "authorInfo";
            this.authorInfo.Size = new System.Drawing.Size(58, 13);
            this.authorInfo.TabIndex = 2;
            this.authorInfo.Text = "Author info";
            // 
            // getPeople
            // 
            this.getPeople.Location = new System.Drawing.Point(16, 137);
            this.getPeople.Name = "getPeople";
            this.getPeople.Size = new System.Drawing.Size(75, 23);
            this.getPeople.TabIndex = 3;
            this.getPeople.Text = "Get People";
            this.getPeople.UseVisualStyleBackColor = true;
            this.getPeople.Click += new System.EventHandler(this.getPeople_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(111, 75);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 262);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.getPeople);
            this.Controls.Add(this.authorInfo);
            this.Controls.Add(this.aboutDescription);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox aboutDescription;
        private System.Windows.Forms.Label authorInfo;
        private System.Windows.Forms.Button getPeople;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

