﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3a
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Populate();
        }

        private void Populate()
        {
            // get About information
            string jsonAbout = getRestData("/about/");

            // need a way to get the JSON form into an About object
            About about = JToken.Parse(jsonAbout).ToObject<About>();

            // start displaying the About object information on the screen
            aboutDescription.Text = about.description;
            authorInfo.Text = about.quoteAuthor;
        }
        
        #region getRestData - Returns the requested API information as a string
        private string getRestData(string url)
        {
            string baseUri = "http://ist.rit.edu/api";

            // connect to the API
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUri + url);
            try
            {
                WebResponse response = request.GetResponse();

                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    return reader.ReadToEnd();
                }
            }
            catch (WebException we)
            {
                // Something goes wrong, get the error response, then do something with it
                WebResponse err = we.Response;
                using (Stream responseStream = err.GetResponseStream())
                {
                    StreamReader r = new StreamReader(responseStream, Encoding.UTF8);
                    string errorText = r.ReadToEnd();
                    // display or log error
                    Console.WriteLine(errorText);
                }
                throw;
            }
        } // end getRestData
        #endregion

        private void getPeople_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Console.WriteLine("btn that got us here is: " + btn.Name);
            Console.WriteLine(sender.ToString());
            Console.WriteLine(sender.GetType().Name);
            Console.WriteLine("e = "+e.ToString());


            // get the JSON for people
            string jsonPeople = getRestData("/people/");

            // cast it to a People object 
            People people = JToken.Parse(jsonPeople).ToObject<People>();
            
            // Show all the faculty names and pictures
            foreach(Faculty thisFac in people.faculty)
            {
                // Console.WriteLine(thisFac.name);     // Uncomment to see all faculty
                pictureBox1.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
            }
        } // end getPeople

        private void aboutDescription_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
