﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tabs340
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] names = { "About", "Degrees", "Minors", "Employment" };
            foreach (TabPage tab in tabControl1.TabPages)
            {
                if (!names.Contains(tab.Text))
                {
                    // need to get the index
                    int tindex = tabControl1.TabPages.IndexOf(tab);

                    // kill the tab
                    tabControl1.TabPages.RemoveAt(tindex);
                }
            } // end for

            // Dynamically add a new tab
            string title = "News";
            TabPage myTabPage = new TabPage(title);
            tabControl1.TabPages.Add(myTabPage);

            TextBox mt = new TextBox();
            mt.BackColor = SystemColors.Info;
            mt.Location = new Point(10, 10);
            mt.Size = new Size(170, 30);
            mt.TabIndex = 1;
            myTabPage.Controls.Add(mt);

        } // end Form1_Load

        private void tabControl1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tab Contron 1 click");
        }

        private void tabAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tab About Click");
        }

        private void tabAbout_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Tab About enter");
        }
    }
}
