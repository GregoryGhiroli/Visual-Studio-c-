﻿namespace GridList
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgEmployer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDegree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgCity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTerm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listView1 = new System.Windows.Forms.ListView();
            this.dataGrid = new System.Windows.Forms.Button();
            this.listView = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgEmployer,
            this.dgDegree,
            this.dgCity,
            this.dgTerm});
            this.dataGridView1.Location = new System.Drawing.Point(210, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(449, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // dgEmployer
            // 
            this.dgEmployer.HeaderText = "Employer";
            this.dgEmployer.Name = "dgEmployer";
            // 
            // dgDegree
            // 
            this.dgDegree.HeaderText = "Degree";
            this.dgDegree.Name = "dgDegree";
            // 
            // dgCity
            // 
            this.dgCity.HeaderText = "City";
            this.dgCity.Name = "dgCity";
            // 
            // dgTerm
            // 
            this.dgTerm.HeaderText = "Term";
            this.dgTerm.Name = "dgTerm";
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(210, 190);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(449, 173);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // dataGrid
            // 
            this.dataGrid.Location = new System.Drawing.Point(51, 60);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(134, 23);
            this.dataGrid.TabIndex = 2;
            this.dataGrid.Text = "Show DataGrid";
            this.dataGrid.UseVisualStyleBackColor = true;
            this.dataGrid.Click += new System.EventHandler(this.dataGrid_Click);
            // 
            // listView
            // 
            this.listView.Location = new System.Drawing.Point(51, 260);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(134, 23);
            this.listView.TabIndex = 3;
            this.listView.Text = "Show ListView";
            this.listView.UseVisualStyleBackColor = true;
            this.listView.Click += new System.EventHandler(this.listView_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 386);
            this.Controls.Add(this.listView);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgEmployer;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDegree;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgCity;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTerm;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button dataGrid;
        private System.Windows.Forms.Button listView;
    }
}

