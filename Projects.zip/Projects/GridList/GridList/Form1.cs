﻿using Newtonsoft.Json.Linq;
using RESTUtil;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace GridList
{
    public partial class Form1 : Form
    {
        Rest rj = new Rest("http://ist.rit.edu/api");
        //Rest rGoogle = new Rest("http://json.google.com/stuff");
        Employment emp;


        //create a stopwatch form timing differet activites

        Stopwatch sw = new Stopwatch();



        public Form1()
        {
            InitializeComponent();
        }

        private void dataGrid_Click(object sender, EventArgs e)
        {
            sw.Reset();
            sw.Start();
            for(var i=0; i<emp.coopTable.coopInformation.Count; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value = 
                    emp.coopTable.coopInformation[i].employer;
                dataGridView1.Rows[i].Cells[1].Value =
                    emp.coopTable.coopInformation[i].degree;
                dataGridView1.Rows[i].Cells[2].Value =
                    emp.coopTable.coopInformation[i].city;
                dataGridView1.Rows[i].Cells[3].Value =
                    emp.coopTable.coopInformation[i].term;
            }
            Console.WriteLine("GridTime = " + sw.ElapsedMilliseconds.ToString());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // get employment data for data grid and list view
            string jsonEmp = rj.getRestData("/employment/");
            // cast it to the object Employment
            emp = JToken.Parse(jsonEmp).ToObject<Employment>();

            listView1.View = View.Details;
            listView1.FullRowSelect = true;
            listView1.Width = 710;
            listView1.Columns.Add("Employer",200);
            listView1.Columns.Add("Degree", 200);
            listView1.Columns.Add("City", 200);
            listView1.Columns.Add("Term", 200);
       }

        private void listView_Click(object sender, EventArgs e)
        {
            sw.Reset();
            sw.Start();
            for (var i = 0; i < emp.coopTable.coopInformation.Count; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value =
                    emp.coopTable.coopInformation[i].employer;
                dataGridView1.Rows[i].Cells[1].Value =
                    emp.coopTable.coopInformation[i].degree;
                dataGridView1.Rows[i].Cells[2].Value =
                    emp.coopTable.coopInformation[i].city;
                dataGridView1.Rows[i].Cells[3].Value =
                    emp.coopTable.coopInformation[i].term;
            }
            Console.WriteLine("GridTime = " + sw.ElapsedMilliseconds.ToString());
        }
    }
}
