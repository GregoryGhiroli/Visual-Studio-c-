﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace DataConsumer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bText_Click(object sender, EventArgs e)
        {

            cbTxt.Items.Clear();

            string val = "";
            StreamReader sr = new StreamReader(@"C:\Users\Gregory\Documents\Visual Studio 2013\Projects\C#fileIOStarter\week11.txt");

            while((val = sr.ReadLine()) != null){


                cbTxt.Items.Add(val);




            }//end of while loop
            sr.Close();

        }

        private void bJson_Click(object sender, EventArgs e)
        {

            cbJson.Items.Clear();


            StreamReader readJSON = new StreamReader(@"C:\Users\Gregory\Documents\Visual Studio 2013\Projects\C#fileIOStarter\week11.json");

            string json = readJSON.ReadToEnd();


            List<string> vals = JsonConvert.DeserializedObject<List<string>>(json);



            foreach (string val in vals)
            {

                cbJson.Items.Add(val);



            }

            readJSON.Close();




        }

        private void bXML_Click(object sender, EventArgs e)
        {
            cbXML.Items.Clear();
            
            XmlReader xr =  XmlReader.Create(@"C:\Users\Gregory\Documents\Visual Studio 2013\Projects\C#fileIOStarter\week11.xml");

            while(xr.Read()){
                if (xr.NodeType == XmlNodeType.Text)
                {

                    cbXML.Items.Add(xr.Value);
                }

            }


            xr.Close();






        }//End of cb button
    }
}
