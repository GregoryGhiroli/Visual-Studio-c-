﻿namespace DataConsumer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bText = new System.Windows.Forms.Button();
            this.bJson = new System.Windows.Forms.Button();
            this.bXML = new System.Windows.Forms.Button();
            this.cbTxt = new System.Windows.Forms.ComboBox();
            this.cbJson = new System.Windows.Forms.ComboBox();
            this.cbXML = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // bText
            // 
            this.bText.Location = new System.Drawing.Point(200, 321);
            this.bText.Name = "bText";
            this.bText.Size = new System.Drawing.Size(75, 23);
            this.bText.TabIndex = 0;
            this.bText.Text = "button1";
            this.bText.UseVisualStyleBackColor = true;
            // 
            // bJson
            // 
            this.bJson.Location = new System.Drawing.Point(426, 320);
            this.bJson.Name = "bJson";
            this.bJson.Size = new System.Drawing.Size(75, 23);
            this.bJson.TabIndex = 1;
            this.bJson.Text = "button2";
            this.bJson.UseVisualStyleBackColor = true;
            this.bJson.Click += new System.EventHandler(this.bJson_Click);
            // 
            // bXML
            // 
            this.bXML.Location = new System.Drawing.Point(707, 320);
            this.bXML.Name = "bXML";
            this.bXML.Size = new System.Drawing.Size(75, 23);
            this.bXML.TabIndex = 2;
            this.bXML.Text = "button3";
            this.bXML.UseVisualStyleBackColor = true;
            this.bXML.Click += new System.EventHandler(this.bXML_Click);
            // 
            // cbTxt
            // 
            this.cbTxt.FormattingEnabled = true;
            this.cbTxt.Location = new System.Drawing.Point(200, 93);
            this.cbTxt.Name = "cbTxt";
            this.cbTxt.Size = new System.Drawing.Size(121, 21);
            this.cbTxt.TabIndex = 3;
            // 
            // cbJson
            // 
            this.cbJson.FormattingEnabled = true;
            this.cbJson.Location = new System.Drawing.Point(426, 93);
            this.cbJson.Name = "cbJson";
            this.cbJson.Size = new System.Drawing.Size(121, 21);
            this.cbJson.TabIndex = 4;
            // 
            // cbXML
            // 
            this.cbXML.FormattingEnabled = true;
            this.cbXML.Location = new System.Drawing.Point(707, 93);
            this.cbXML.Name = "cbXML";
            this.cbXML.Size = new System.Drawing.Size(121, 21);
            this.cbXML.TabIndex = 5;
            // 
            // comboBox4
            // 
            this.comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "this is",
            "the ",
            "text",
            " that we",
            "typed ",
            "into the",
            "combo box",
            "to show up"});
            this.comboBox4.Location = new System.Drawing.Point(426, 443);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 543);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.cbXML);
            this.Controls.Add(this.cbJson);
            this.Controls.Add(this.cbTxt);
            this.Controls.Add(this.bXML);
            this.Controls.Add(this.bJson);
            this.Controls.Add(this.bText);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bText;
        private System.Windows.Forms.Button bJson;
        private System.Windows.Forms.Button bXML;
        private System.Windows.Forms.ComboBox cbTxt;
        private System.Windows.Forms.ComboBox cbJson;
        private System.Windows.Forms.ComboBox cbXML;
        private System.Windows.Forms.ComboBox comboBox4;
    }
}

