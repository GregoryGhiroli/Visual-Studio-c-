﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tabs754
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // this type of user can only see these items
            string[] names = { "About", "Degrees", "Minors", "Employment" };

            // Remove the tabs that this user cannot access
            foreach (TabPage tab in tabControl1.TabPages)
            {
                // If the name is not in the list, remove it
                if (!names.Contains(tab.Text))
                {
                    // get the index of this tab
                    int tabIndex = tabControl1.TabPages.IndexOf(tab);

                    // Remove the tab
                    tabControl1.TabPages.RemoveAt(tabIndex);
                }
            } // end foreach

            // Dynamically add a tab
            string title = "News";
            TabPage myTabPage = new TabPage(title);
            tabControl1.TabPages.Add(myTabPage);

            TextBox mt = new TextBox();
            mt.BackColor = SystemColors.Info;
            mt.Location = new Point(20, 10);
            mt.Size = new Size(170, 30);
            mt.TabIndex = 1;
            myTabPage.Controls.Add(mt);
            
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("tab control1 click");
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("tab page 1 - About - click");
        }

        private void tabPage1_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("tab page 1 = About = Enter");
        }

        private void tabDegrees_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Tab Degrees - Enter");
        }
    }
}
