﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestConnections
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
        }

        private void btnConnectMySQL_Click(object sender, EventArgs e)
        {
            try
            {
                //go to references and add SqlConnection
                MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection("server=127.0.0.1;Database=travel;uid=root;pwd=Apr26gpg#$%;");


                conn.Open();

                MessageBox.Show("MySql connected");
                conn.Close();
                MessageBox.Show("MySQl closed!");

                
            }//end of try
            catch(Exception E)
            {
                MessageBox.Show("Error" + E.Message);

                Console.WriteLine("Error operaing mySql");



            }//end of catch
        }

        private void btnConnectSQLServer_Click(object sender, EventArgs e)
        {
            String connStr = "Server=theodore.ist.rit.edu;Database=Jobs;User Id=330User;Password=330Password;";

            try
            {
                //MySqlConnection = SqlConnection , needs reference from sql files
                //using.system.Data.SqlClient

                MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);

                MessageBox.Show("Connected to SQL Server");

                conn.Open();

                MessageBox.Show("Server Closing");

                conn.Close();



            }//end of try
            catch (Exception E)
            {
                MessageBox.Show("Error" + E.Message);

                Console.WriteLine("Error operaing mySql");



            }//end of catch

            MessageBox.Show("End of SQL service");
        }
    }
}
