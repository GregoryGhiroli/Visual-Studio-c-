﻿namespace TestConnections
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnectMySQL = new System.Windows.Forms.Button();
            this.btnConnectSQLServer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnConnectMySQL
            // 
            this.btnConnectMySQL.Location = new System.Drawing.Point(127, 72);
            this.btnConnectMySQL.Name = "btnConnectMySQL";
            this.btnConnectMySQL.Size = new System.Drawing.Size(331, 73);
            this.btnConnectMySQL.TabIndex = 0;
            this.btnConnectMySQL.Text = "MySqlConnect";
            this.btnConnectMySQL.UseVisualStyleBackColor = true;
            this.btnConnectMySQL.Click += new System.EventHandler(this.btnConnectMySQL_Click);
            // 
            // btnConnectSQLServer
            // 
            this.btnConnectSQLServer.Location = new System.Drawing.Point(127, 247);
            this.btnConnectSQLServer.Name = "btnConnectSQLServer";
            this.btnConnectSQLServer.Size = new System.Drawing.Size(331, 51);
            this.btnConnectSQLServer.TabIndex = 1;
            this.btnConnectSQLServer.Text = "SQLServer";
            this.btnConnectSQLServer.UseVisualStyleBackColor = true;
            this.btnConnectSQLServer.Click += new System.EventHandler(this.btnConnectSQLServer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 459);
            this.Controls.Add(this.btnConnectSQLServer);
            this.Controls.Add(this.btnConnectMySQL);
            this.Name = "Form1";
            this.Text = "Database Connection";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnConnectMySQL;
        private System.Windows.Forms.Button btnConnectSQLServer;
    }
}

