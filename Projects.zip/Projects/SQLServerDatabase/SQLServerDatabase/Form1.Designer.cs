﻿namespace SQLServerDatabase
{
    partial class SqlServerDataBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntServerConnect = new System.Windows.Forms.Button();
            this.bntSqlServerConnect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bntServerConnect
            // 
            this.bntServerConnect.Location = new System.Drawing.Point(138, 31);
            this.bntServerConnect.Name = "bntServerConnect";
            this.bntServerConnect.Size = new System.Drawing.Size(165, 138);
            this.bntServerConnect.TabIndex = 0;
            this.bntServerConnect.Text = "Connect to Server";
            this.bntServerConnect.UseVisualStyleBackColor = true;
            this.bntServerConnect.Click += new System.EventHandler(this.bntServerConnect_Click);
            // 
            // bntSqlServerConnect
            // 
            this.bntSqlServerConnect.Location = new System.Drawing.Point(138, 216);
            this.bntSqlServerConnect.Name = "bntSqlServerConnect";
            this.bntSqlServerConnect.Size = new System.Drawing.Size(165, 130);
            this.bntSqlServerConnect.TabIndex = 1;
            this.bntSqlServerConnect.Text = "Connect to MySql";
            this.bntSqlServerConnect.UseVisualStyleBackColor = true;
            this.bntSqlServerConnect.Click += new System.EventHandler(this.bntSqlServerConnect_Click);
            // 
            // SqlServerDataBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 414);
            this.Controls.Add(this.bntSqlServerConnect);
            this.Controls.Add(this.bntServerConnect);
            this.Name = "SqlServerDataBase";
            this.Text = "Sql Server Database";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bntServerConnect;
        private System.Windows.Forms.Button bntSqlServerConnect;
    }
}

