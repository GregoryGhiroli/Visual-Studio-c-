﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQLServerDatabase
{
    public partial class SqlServerDataBase : Form
    {
        public SqlServerDataBase()
        {
            InitializeComponent();

            // Create two attributes for each connection, (must be inside constructor)
           // string Password = "Password=330Password;";
           // string Username = "User Id=330User;";

            //A connection attribute that holds the connection database object
           // string connection = "Server=theodore.ist.rit.edu;Database=Jobs;User Id=330User;Password=330Password;";
           // string travelConnection = "server=127.0.0.1;Database=travel;uid=root;pwd=student;";
        }

        private void bntServerConnect_Click(object sender, EventArgs e)
        {

            try
            {

            //Connection String
            string connection = "Server=theodore.ist.rit.edu;Database=Jobs;User Id=330User;Password=330Password;";



            //MySqlConnection = SqlConnection , needs reference from sql files
            //using.system.Data.SqlClient

            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connection);

            MessageBox.Show("Connected to SQL Server");

            //Open server
            conn.Open();

            MessageBox.Show("Server Closing");

            //Close Server
            conn.Close();

            }//end of try statement


             catch (Exception E)
            {
                MessageBox.Show("Error" + E.Message);

                Console.WriteLine("Error operaing mySql");



            }//end of catch

            MessageBox.Show("End of SQL service");
        }

        private void bntSqlServerConnect_Click(object sender, EventArgs e)
        {
            try
            {

                //create a trvael connection attribute

               string travelConnection = "server=127.0.0.1;Database=travel;uid=root;pwd=student;";
        

                //go to references and add SqlConnection
               MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(travelConnection);

                //open connection
                conn.Open();

                MessageBox.Show("MySql connected");

                //close connection
                conn.Close();
                MessageBox.Show("MySQl closed!");


            }//end of try
            catch (Exception E)
            {
                MessageBox.Show("Error" + E.Message);

                Console.WriteLine("Error operaing mySql");



            }//end of catch
        }
    }
}
