﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RESTDLL
{
    public class Rest
    {
        private string baseURI;

        //Constructor parameter sets the URI for this object
        public Rest(string url)
        {
            baseUrl = url;




        }
        
        #region getRestData - Returns the requested API information as a string
        public string getRestData(string url)
        {
            string baseUri = "http://ist.rit.edu/api";

            // connect to the API
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUri + url);
            try
            {
                WebResponse response = request.GetResponse();

                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    return reader.ReadToEnd();
                }
            }
            catch (WebException we)
            {
                // Something goes wrong, get the error response, then do something with it
                WebResponse err = we.Response;
                using (Stream responseStream = err.GetResponseStream())
                {
                    StreamReader r = new StreamReader(responseStream, Encoding.UTF8);
                    string errorText = r.ReadToEnd();
                    // display or log error
                    Console.WriteLine(errorText);
                }
                throw;
            }
        } // end getRestData
        #endregion
/*
        private void getPeople_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Console.WriteLine("btn that got us here is: " + btn.Name);
            Console.WriteLine(sender.ToString());
            Console.WriteLine(sender.GetType().Name);
            Console.WriteLine("e = "+e.ToString());


            // get the JSON for people
            string jsonPeople = getRestData("/people/");

            // cast it to a People object 
            People people = JToken.Parse(jsonPeople).ToObject<People>();
            
            // Show all the faculty names and pictures
            foreach(Faculty thisFac in people.faculty)
            {
                // Console.WriteLine(thisFac.name);     // Uncomment to see all faculty
                pictureBox1.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
            }
        } //end of getpeople
        */


        public string baseUrl { get; set; }
    }//end of rest
}
