﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace weel11aGUIcomponents
{
    public partial class Form1 : Form
    {

        List <string> _items = new List<string>();

        ToolTip myToolTip = new ToolTip();




        public Form1()
        {
            InitializeComponent();

            // List would work for checkbox, listbox, dropdownbox
            _items.Add("One");
            _items.Add("Two");
            _items.Add("Three");
            _items.Add("Four");

            listBox1.DataSource = _items;

            checkBoxList.DataSource = _items;
         
            myToolTip.OwnerDraw = true;
            myToolTip.Draw += new DrawToolTipEventHandler(toolTip1_Draw); 


        }//end of public form 1



    
        private void allCB_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cbSomeCheckBox = sender as CheckBox;

            string str = cbSomeCheckBox.Text;

            txtWhenClicked.Text = str;


           // Way 1 string cbOn = cbSomeCheckBox.Checked + "";

          //  Way 2  string cbOn = cbSomeCheckBox.Checked.ToString();

            //tells true or false when the check box is checked or not
            string cbOn = Convert.ToString(cbSomeCheckBox.Checked);


            txtState.Text = cbOn;




        }

        private void button1_MouseHover(object sender, EventArgs e)
        {

            ToolTip myToolTip = new ToolTip();
            myToolTip.SetToolTip(button1, "This is fun!");



        }

        private void txtWhenClicked_MouseEnter(object sender, EventArgs e)
        {
            ToolTip myToolTip = new ToolTip();


            //more optiosn to play with


            myToolTip.ToolTipIcon = ToolTipIcon.Info;

            myToolTip.IsBalloon = true;

            myToolTip.OwnerDraw = true; 
            myToolTip.BackColor = System.Drawing.Color.Green;
             
            myToolTip.SetToolTip(txtWhenClicked, "More and More Fun!");

        


        }

     public  void toolTip1_Draw(object sender, DrawToolTipEventArgs e)
        {
            Font f = new Font("Arial", 10.0f);
            myToolTip.BackColor = System.Drawing.Color.Red;
            e.DrawBackground();
            e.DrawBorder();
            e.Graphics.DrawString(e.ToolTipText, f, Brushes.Black, new PointF(2, 2));
        }


    

      
    }
}
