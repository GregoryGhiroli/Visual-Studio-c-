﻿using Newtonsoft.Json.Linq;
using RESTUtil;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3b
{
    public partial class Form1 : Form
    {
        Rest rj = new Rest("http://ist.rit.edu/api");
        Rest rjGoogle = new Rest("http://info.google.com/api");
        Employment emp;

        Stopwatch sw = new Stopwatch();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string jsonEmp = rj.getRestData("/employment/");
            emp = JToken.Parse(jsonEmp).ToObject<Employment>();

            // create the headers for the List View
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;

            listView1.Columns.Add("Employer",150);
            listView1.Columns.Add("Degree",100);
            listView1.Columns.Add("City",125);
            listView1.Columns.Add("Term",75);
        }

        private void showDataGrid_Click(object sender, EventArgs e)
        {
            sw.Reset();
            sw.Start();


            for( var i=0; i<emp.coopTable.coopInformation.Count; i++)
            {
                dataGridView1.Rows.Add();       // 1st row added is row 0
                dataGridView1.Rows[i].Cells[0].Value =
                    emp.coopTable.coopInformation[i].employer;
                dataGridView1.Rows[i].Cells[1].Value =
                    emp.coopTable.coopInformation[i].degree;
                dataGridView1.Rows[i].Cells[2].Value =
                    emp.coopTable.coopInformation[i].city;
                dataGridView1.Rows[i].Cells[3].Value =
                    emp.coopTable.coopInformation[i].term;
            }

            sw.Stop();
            Console.WriteLine("Data grid: "+sw.ElapsedMilliseconds.ToString());
        }

        private void showListView_Click(object sender, EventArgs e)
        {
            sw.Reset();
            sw.Start();

            for (var i=0; i<emp.coopTable.coopInformation.Count; i++)
            {
                // create an object to add information into the List View
                ListViewItem item = new ListViewItem(new String[]
                {
                    emp.coopTable.coopInformation[i].employer,
                    emp.coopTable.coopInformation[i].degree,
                    emp.coopTable.coopInformation[i].city,
                    emp.coopTable.coopInformation[i].term
                });
                listView1.Items.Add(item);
            } // end for
            sw.Stop();
            Console.WriteLine("List view: "+sw.ElapsedMilliseconds.ToString());
        }
    }
}
