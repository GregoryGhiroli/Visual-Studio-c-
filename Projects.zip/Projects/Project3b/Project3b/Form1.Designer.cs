﻿namespace Project3b
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showDataGrid = new System.Windows.Forms.Button();
            this.showListView = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgEmployer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDegree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgCity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTerm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // showDataGrid
            // 
            this.showDataGrid.Location = new System.Drawing.Point(43, 43);
            this.showDataGrid.Name = "showDataGrid";
            this.showDataGrid.Size = new System.Drawing.Size(124, 23);
            this.showDataGrid.TabIndex = 0;
            this.showDataGrid.Text = "Show DataGrid";
            this.showDataGrid.UseVisualStyleBackColor = true;
            this.showDataGrid.Click += new System.EventHandler(this.showDataGrid_Click);
            // 
            // showListView
            // 
            this.showListView.Location = new System.Drawing.Point(43, 257);
            this.showListView.Name = "showListView";
            this.showListView.Size = new System.Drawing.Size(124, 23);
            this.showListView.TabIndex = 1;
            this.showListView.Text = "Show ListView";
            this.showListView.UseVisualStyleBackColor = true;
            this.showListView.Click += new System.EventHandler(this.showListView_Click);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(191, 193);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(453, 159);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgEmployer,
            this.dgDegree,
            this.dgCity,
            this.dgTerm});
            this.dataGridView1.Location = new System.Drawing.Point(191, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(453, 150);
            this.dataGridView1.TabIndex = 3;
            // 
            // dgEmployer
            // 
            this.dgEmployer.HeaderText = "Employer";
            this.dgEmployer.Name = "dgEmployer";
            // 
            // dgDegree
            // 
            this.dgDegree.HeaderText = "Degree";
            this.dgDegree.Name = "dgDegree";
            // 
            // dgCity
            // 
            this.dgCity.HeaderText = "City";
            this.dgCity.Name = "dgCity";
            // 
            // dgTerm
            // 
            this.dgTerm.HeaderText = "Term";
            this.dgTerm.Name = "dgTerm";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 392);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.showListView);
            this.Controls.Add(this.showDataGrid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showDataGrid;
        private System.Windows.Forms.Button showListView;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgEmployer;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDegree;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgCity;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTerm;
    }
}

