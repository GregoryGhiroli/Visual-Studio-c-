﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DragNDrop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_MouseDown(object sender, MouseEventArgs e)
        {
            // Pick up an item and throw it

            if(this.listBox1.SelectedItem != null)
            {

                DoDragDrop(this.listBox1.SelectedItem, DragDropEffects.Copy);




            }

        }//end of listboc mouse down

        private void treeView1_DragDrop(object sender, DragEventArgs e)
        {
            Console.WriteLine("Drop");
            // put it in da box


            string item = (string)e.Data.GetData("Text");
            treeView1.Nodes.Add(item);



        }

        private void treeView1_DragEnter(object sender, DragEventArgs e)
        {
            Console.WriteLine("Enter");

            //give it something to drop

            if(e.Data.GetDataPresent("Text"))
            {


                e.Effect = DragDropEffects.Copy;


            }

            else
            {
                e.Effect = DragDropEffects.None;



            }

        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {



            Point p = System.Windows.Forms.Cursor.Position;

            //Add text to a gui needs a label


            Label lab = new Label();


            //st the location of this label

            lab.Location = PointToClient(p);


            //Get the text of what we want to add to the screen


            lab.Text = (string)e.Data.GetData("Text");



            //add this label to the screen

            this.Controls.Add(lab);




        }
    }
}
