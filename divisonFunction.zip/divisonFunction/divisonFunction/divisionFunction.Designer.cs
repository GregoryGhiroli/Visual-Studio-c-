﻿namespace divisonFunction
{
    partial class divisionFunction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionlabel1 = new System.Windows.Forms.Label();
            this.instrcutionlabel2 = new System.Windows.Forms.Label();
            this.instrcutionlabel3 = new System.Windows.Forms.Label();
            this.instrcutionlabel4 = new System.Windows.Forms.Label();
            this.detailedlabel5 = new System.Windows.Forms.Label();
            this.detialedlabel6 = new System.Windows.Forms.Label();
            this.intQuotientLabel = new System.Windows.Forms.Label();
            this.remainderLabel = new System.Windows.Forms.Label();
            this.doubleQuotientLabel = new System.Windows.Forms.Label();
            this.dividendRoundedLabel = new System.Windows.Forms.Label();
            this.dividendTextBox = new System.Windows.Forms.TextBox();
            this.divisorTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionlabel1
            // 
            this.instructionlabel1.AutoSize = true;
            this.instructionlabel1.Location = new System.Drawing.Point(13, 55);
            this.instructionlabel1.Name = "instructionlabel1";
            this.instructionlabel1.Size = new System.Drawing.Size(49, 13);
            this.instructionlabel1.TabIndex = 0;
            this.instructionlabel1.Text = "Dividend";
            // 
            // instrcutionlabel2
            // 
            this.instrcutionlabel2.AutoSize = true;
            this.instrcutionlabel2.Location = new System.Drawing.Point(13, 111);
            this.instrcutionlabel2.Name = "instrcutionlabel2";
            this.instrcutionlabel2.Size = new System.Drawing.Size(39, 13);
            this.instrcutionlabel2.TabIndex = 1;
            this.instrcutionlabel2.Text = "Divisor";
            // 
            // instrcutionlabel3
            // 
            this.instrcutionlabel3.AutoSize = true;
            this.instrcutionlabel3.Location = new System.Drawing.Point(13, 150);
            this.instrcutionlabel3.Name = "instrcutionlabel3";
            this.instrcutionlabel3.Size = new System.Drawing.Size(61, 13);
            this.instrcutionlabel3.TabIndex = 2;
            this.instrcutionlabel3.Text = "int Quotient";
            // 
            // instrcutionlabel4
            // 
            this.instrcutionlabel4.AutoSize = true;
            this.instrcutionlabel4.Location = new System.Drawing.Point(13, 197);
            this.instrcutionlabel4.Name = "instrcutionlabel4";
            this.instrcutionlabel4.Size = new System.Drawing.Size(58, 13);
            this.instrcutionlabel4.TabIndex = 3;
            this.instrcutionlabel4.Text = "Remainder";
            // 
            // detailedlabel5
            // 
            this.detailedlabel5.AutoSize = true;
            this.detailedlabel5.Location = new System.Drawing.Point(13, 235);
            this.detailedlabel5.Name = "detailedlabel5";
            this.detailedlabel5.Size = new System.Drawing.Size(66, 13);
            this.detailedlabel5.TabIndex = 4;
            this.detailedlabel5.Text = "Dbl Quotient";
            // 
            // detialedlabel6
            // 
            this.detialedlabel6.AutoSize = true;
            this.detialedlabel6.Location = new System.Drawing.Point(13, 280);
            this.detialedlabel6.Name = "detialedlabel6";
            this.detialedlabel6.Size = new System.Drawing.Size(96, 13);
            this.detialedlabel6.TabIndex = 5;
            this.detialedlabel6.Text = "Dividend Rounded";
            // 
            // intQuotientLabel
            // 
            this.intQuotientLabel.AutoSize = true;
            this.intQuotientLabel.Location = new System.Drawing.Point(206, 150);
            this.intQuotientLabel.Name = "intQuotientLabel";
            this.intQuotientLabel.Size = new System.Drawing.Size(35, 13);
            this.intQuotientLabel.TabIndex = 6;
            this.intQuotientLabel.Text = "label7";
            // 
            // remainderLabel
            // 
            this.remainderLabel.AutoSize = true;
            this.remainderLabel.Location = new System.Drawing.Point(209, 196);
            this.remainderLabel.Name = "remainderLabel";
            this.remainderLabel.Size = new System.Drawing.Size(35, 13);
            this.remainderLabel.TabIndex = 7;
            this.remainderLabel.Text = "label8";
            // 
            // doubleQuotientLabel
            // 
            this.doubleQuotientLabel.AutoSize = true;
            this.doubleQuotientLabel.Location = new System.Drawing.Point(209, 234);
            this.doubleQuotientLabel.Name = "doubleQuotientLabel";
            this.doubleQuotientLabel.Size = new System.Drawing.Size(35, 13);
            this.doubleQuotientLabel.TabIndex = 8;
            this.doubleQuotientLabel.Text = "label9";
            // 
            // dividendRoundedLabel
            // 
            this.dividendRoundedLabel.AutoSize = true;
            this.dividendRoundedLabel.Location = new System.Drawing.Point(209, 280);
            this.dividendRoundedLabel.Name = "dividendRoundedLabel";
            this.dividendRoundedLabel.Size = new System.Drawing.Size(41, 13);
            this.dividendRoundedLabel.TabIndex = 9;
            this.dividendRoundedLabel.Text = "label10";
            // 
            // dividendTextBox
            // 
            this.dividendTextBox.Location = new System.Drawing.Point(209, 55);
            this.dividendTextBox.Name = "dividendTextBox";
            this.dividendTextBox.Size = new System.Drawing.Size(100, 20);
            this.dividendTextBox.TabIndex = 10;
            // 
            // divisorTextBox
            // 
            this.divisorTextBox.Location = new System.Drawing.Point(209, 111);
            this.divisorTextBox.Name = "divisorTextBox";
            this.divisorTextBox.Size = new System.Drawing.Size(100, 20);
            this.divisorTextBox.TabIndex = 11;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(212, 365);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(16, 365);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 13;
            this.calculateButton.Text = "Calculate Button";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // divisionFunction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 420);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.divisorTextBox);
            this.Controls.Add(this.dividendTextBox);
            this.Controls.Add(this.dividendRoundedLabel);
            this.Controls.Add(this.doubleQuotientLabel);
            this.Controls.Add(this.remainderLabel);
            this.Controls.Add(this.intQuotientLabel);
            this.Controls.Add(this.detialedlabel6);
            this.Controls.Add(this.detailedlabel5);
            this.Controls.Add(this.instrcutionlabel4);
            this.Controls.Add(this.instrcutionlabel3);
            this.Controls.Add(this.instrcutionlabel2);
            this.Controls.Add(this.instructionlabel1);
            this.Name = "divisionFunction";
            this.Text = "Division Function";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionlabel1;
        private System.Windows.Forms.Label instrcutionlabel2;
        private System.Windows.Forms.Label instrcutionlabel3;
        private System.Windows.Forms.Label instrcutionlabel4;
        private System.Windows.Forms.Label detailedlabel5;
        private System.Windows.Forms.Label detialedlabel6;
        private System.Windows.Forms.Label intQuotientLabel;
        private System.Windows.Forms.Label remainderLabel;
        private System.Windows.Forms.Label doubleQuotientLabel;
        private System.Windows.Forms.Label dividendRoundedLabel;
        private System.Windows.Forms.TextBox dividendTextBox;
        private System.Windows.Forms.TextBox divisorTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
    }
}

