﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace divisonFunction
{
    public partial class divisionFunction : Form
    {
        public divisionFunction()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private double roundedDivinded(double dividend)
        {
            return Math.Round(dividend,2);
        }
        private double dblquotient(double dividend, double divisor)
        {
            return dividend / divisor;
        }
        private int remainder(double dividend, double divisor)
        {
            return ((int)dividend % (int)divisor);
        }

        private int quotient(double dividend, double divisor)
        {
            int result;

            result = ((int)dividend / (int)divisor);

            return result;
        }










        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double dividend, divisor;

                if (double.TryParse(dividendTextBox.Text, out dividend))
                {
                    if (double.TryParse(divisorTextBox.Text, out divisor))
                    {
                        if (divisor != 0)
                        {
                            intQuotientLabel.Text = quotient(dividend, divisor).ToString();
                            remainderLabel.Text = remainder(dividend, divisor).ToString();
                            doubleQuotientLabel.Text = (dblquotient(dividend, divisor)).ToString("n2");
                            dividendRoundedLabel.Text = roundedDivinded(dividend).ToString("n2");

                        }
                        else { MessageBox.Show(" Divisor did not equal 0"); }
                    }
                    else { MessageBox.Show(" No dividing by Zero"); }
                }
                else { MessageBox.Show("Invalid Input"); }
            }
            catch
            {
                MessageBox.Show("Enter a number please ");
            }
        }
    }
}
