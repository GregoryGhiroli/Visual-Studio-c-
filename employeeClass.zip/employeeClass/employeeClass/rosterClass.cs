﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employeeClass
{
    class rosterClass
    {
         private string _name;
        private decimal _number;
        private string _depart;
        private string _post;

        public rosterClass()
        {
            _number = 0m;
            _name = "";
            _depart = "";
            _post = "";
        }
        public string Name
        {
            get{return _name;}
            set{ _name = value;}
        }
        public decimal Number
        {
            get { return _number; }
            set { _number = value; }
        }
        public string Depart
        {
            get { return _depart; }
            set { _depart = value; }
        }
        public string Post
        {
            get{ return _post;}
            set{ _post = value;}
        }
    }
}
