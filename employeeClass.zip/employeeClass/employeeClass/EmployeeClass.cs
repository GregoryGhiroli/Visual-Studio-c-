﻿


/*Gregory Ghiroli
 * i ran out of teim
 * 
 */ using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employeeClass
{
    public partial class EmployeeClass : Form
    {
        public EmployeeClass()
        {
            InitializeComponent();
        }
        List<rosterClass> rosterList = new List<rosterClass>();


        private void GetRosterData(rosterClass roster)
        {
           
            decimal number;


            roster.Name = nameTextBox.Text;
            roster.Post = postTextBox.Text;
            roster.Depart = departTextBox.Text;
           
            if (decimal.TryParse(numberTextBox.Text, out number))
            {
                roster.Number = number;

            }
            else
            {
                MessageBox.Show("Invalid price");
            }


        }
        private void addButton_Click(object sender, EventArgs e)
        {
            rosterClass myRoster = new rosterClass();

            GetRosterData(myRoster);
        }

        private void EmployeeClass_Load(object sender, EventArgs e)
        {
            showListBox.Items.Add("name" + " " + "id" + " " + "department"+""+"postition");
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            rosterClass myRoster = new rosterClass();

            GetRosterData(myRoster);
            

            showListBox.Items.Add(myRoster.Name + " " + myRoster.Number.ToString()+ " " + myRoster.Depart+" "+ myRoster.Post);

            numberTextBox.Clear();

            departTextBox.Clear();

            postTextBox.Clear();
        }
    }
}
