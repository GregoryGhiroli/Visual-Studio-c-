﻿namespace Orion_Constellation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Orion = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.betelguese = new System.Windows.Forms.Label();
            this.Alnitak = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Alnilam = new System.Windows.Forms.Label();
            this.Mintaka = new System.Windows.Forms.Label();
            this.Rigel = new System.Windows.Forms.Label();
            this.Meissa = new System.Windows.Forms.Label();
            this.Saiph = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Orion)).BeginInit();
            this.SuspendLayout();
            // 
            // Orion
            // 
            this.Orion.Image = ((System.Drawing.Image)(resources.GetObject("Orion.Image")));
            this.Orion.Location = new System.Drawing.Point(110, 48);
            this.Orion.Name = "Orion";
            this.Orion.Size = new System.Drawing.Size(738, 487);
            this.Orion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Orion.TabIndex = 0;
            this.Orion.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(264, 584);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Show names";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(431, 583);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Hide names";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(621, 584);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // betelguese
            // 
            this.betelguese.AutoSize = true;
            this.betelguese.Location = new System.Drawing.Point(221, 94);
            this.betelguese.Name = "betelguese";
            this.betelguese.Size = new System.Drawing.Size(59, 13);
            this.betelguese.TabIndex = 4;
            this.betelguese.Text = "betelgeuse";
            // 
            // Alnitak
            // 
            this.Alnitak.AutoSize = true;
            this.Alnitak.Location = new System.Drawing.Point(315, 285);
            this.Alnitak.Name = "Alnitak";
            this.Alnitak.Size = new System.Drawing.Size(39, 13);
            this.Alnitak.TabIndex = 5;
            this.Alnitak.Text = "Alnitak";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(354, 415);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 6;
            // 
            // Alnilam
            // 
            this.Alnilam.AutoSize = true;
            this.Alnilam.Location = new System.Drawing.Point(431, 285);
            this.Alnilam.Name = "Alnilam";
            this.Alnilam.Size = new System.Drawing.Size(40, 13);
            this.Alnilam.TabIndex = 7;
            this.Alnilam.Text = "Alnilam";
            // 
            // Mintaka
            // 
            this.Mintaka.AutoSize = true;
            this.Mintaka.Location = new System.Drawing.Point(532, 260);
            this.Mintaka.Name = "Mintaka";
            this.Mintaka.Size = new System.Drawing.Size(45, 13);
            this.Mintaka.TabIndex = 8;
            this.Mintaka.Text = "Mintaka";
            // 
            // Rigel
            // 
            this.Rigel.AutoSize = true;
            this.Rigel.Location = new System.Drawing.Point(621, 435);
            this.Rigel.Name = "Rigel";
            this.Rigel.Size = new System.Drawing.Size(31, 13);
            this.Rigel.TabIndex = 9;
            this.Rigel.Text = "Rigel";
            // 
            // Meissa
            // 
            this.Meissa.AutoSize = true;
            this.Meissa.Location = new System.Drawing.Point(624, 137);
            this.Meissa.Name = "Meissa";
            this.Meissa.Size = new System.Drawing.Size(40, 13);
            this.Meissa.TabIndex = 10;
            this.Meissa.Text = "Meissa";
            // 
            // Saiph
            // 
            this.Saiph.AutoSize = true;
            this.Saiph.Location = new System.Drawing.Point(264, 435);
            this.Saiph.Name = "Saiph";
            this.Saiph.Size = new System.Drawing.Size(34, 13);
            this.Saiph.TabIndex = 11;
            this.Saiph.Text = "Saiph";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 655);
            this.Controls.Add(this.Saiph);
            this.Controls.Add(this.Meissa);
            this.Controls.Add(this.Rigel);
            this.Controls.Add(this.Mintaka);
            this.Controls.Add(this.Alnilam);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Alnitak);
            this.Controls.Add(this.betelguese);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Orion);
            this.Name = "Form1";
            this.Text = "Orion Constellation";
            ((System.ComponentModel.ISupportInitialize)(this.Orion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Orion;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label betelguese;
        private System.Windows.Forms.Label Alnitak;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Alnilam;
        private System.Windows.Forms.Label Mintaka;
        private System.Windows.Forms.Label Rigel;
        private System.Windows.Forms.Label Meissa;
        private System.Windows.Forms.Label Saiph;
    }
}

