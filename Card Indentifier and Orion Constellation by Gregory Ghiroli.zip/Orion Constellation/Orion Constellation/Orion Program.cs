﻿/*
* gregory ghiroli
 * 9/3/14
 * programming NACA 160.01
 * this program shows the star names and hides it. then clikc exit to exit the program
 * 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Orion_Constellation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            betelguese.Visible = true;
            Meissa.Visible = true;
            Rigel.Visible = true;
            Saiph.Visible = true;
            Mintaka.Visible = true;
            Alnilam.Visible = true;
            Alnitak.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            betelguese.Visible = false;
            Meissa.Visible = false;
            Rigel.Visible = false;
            Saiph.Visible = false;
            Mintaka.Visible = false;
            Alnilam.Visible = false;
            Alnitak.Visible = false;
        }
    }
}
