﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorCustoms
{
    public partial class calulatorCustom : Form
    {
        public calulatorCustom()
        {
            InitializeComponent();
        }


        private int Add( int number)
        {
            int num;

            num = number + 3;

            return num;

        }
        private int Subtract(int number)
        {
            int num;

            num = number - 5;

            return num;
        }
        private int Mutiply(int number)
        {
            int num;

            num = (number * 7);

            return num;
        }
        private decimal Divide(decimal number)
        {
            decimal num;

            num = (number / 9);

            return num;
        }


        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            int number;
           
            if(int.TryParse(numberTextBox.Text, out number))
            {
                double total = Add(number);

                numberTextBox.Text = total.ToString();

            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
        }


        private void mutiButton_Click(object sender, EventArgs e)
        {
            int number;

           

            if (int.TryParse(numberTextBox.Text, out number))
            {
                double total = Mutiply(number);

                numberTextBox.Text = total.ToString();
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
        }

        private void subButton_Click(object sender, EventArgs e)
        {
            int number;



            if (int.TryParse(numberTextBox.Text, out number))
            {
                double total = Subtract(number);

                numberTextBox.Text = total.ToString();
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
        }

        private void divButton_Click(object sender, EventArgs e)
        {
            decimal number;

            if (decimal.TryParse(numberTextBox.Text, out number))
            {
                decimal total = Divide(number);

                numberTextBox.Text = total.ToString();
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
        }
    }
}
