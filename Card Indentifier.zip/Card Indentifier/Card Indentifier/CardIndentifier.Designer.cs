﻿/* Gregory Ghiroli
 * 9/3/14
 * Card Indentifier
 * Computer Programming NACA 160
 * The purpose is to indentify the card you click on ,then click the exit button to exit the program
 */






using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Indentifier
{
    public partial class CardIndentifier : Form
    {
        public CardIndentifier()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
         cardlabel.Text = " 8 of Diamonds"; 
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            cardlabel.Text = " 2 of Clubs";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            cardlabel.Text =" King of Spades";
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
           cardlabel.Text =" Ace of Spades";
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            cardlabel.Text =" Black Joker";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
