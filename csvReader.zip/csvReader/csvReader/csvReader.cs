﻿/* Gregory Ghrioli
 * This file reads and averages out numbers in microsfot excel
 * NACA 160.02
 * 11/13/14
 * 
 */ 




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace csvReader
{
    public partial class csvReader : Form
    {
        public csvReader()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void getScoreButton_Click(object sender, EventArgs e)
        {
            try{
                StreamReader inputFile;
                string line;
                int count = 0;
                int total;
                 double average;

                char[] delim = {','};

                inputFile = File.OpenText("Grades.csv");
                while(!inputFile.EndOfStream)
                {
                    count++;
                    line = inputFile.ReadLine();

                    string [] tokens = line.Split(delim);
                    total = 0;

                    foreach( string str in tokens)
                    {
                        total +=int.Parse(str);
                    }

                    average = (double)total / tokens.Length;
                    averageListBox.Items.Add("The average for students " + count+" is "+ average.ToString("n1"));
                }
               inputFile.Close();
            }
            catch(Exception ex)

            {
                MessageBox.Show(ex.Message);

            }

        }

    }
}

