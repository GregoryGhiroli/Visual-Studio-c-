﻿namespace deathstar
{
    partial class deathStar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lackOfFaithButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.populationLabel = new System.Windows.Forms.Label();
            this.terrainLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lackOfFaithButton
            // 
            this.lackOfFaithButton.Location = new System.Drawing.Point(13, 180);
            this.lackOfFaithButton.Name = "lackOfFaithButton";
            this.lackOfFaithButton.Size = new System.Drawing.Size(363, 205);
            this.lackOfFaithButton.TabIndex = 0;
            this.lackOfFaithButton.Text = "ACTIVATE THE DEATH STAR";
            this.lackOfFaithButton.UseVisualStyleBackColor = true;
            this.lackOfFaithButton.Click += new System.EventHandler(this.lackOfFaithButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Planet:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Terrain:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(90, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Population";
            // 
            // populationLabel
            // 
            this.populationLabel.AutoSize = true;
            this.populationLabel.Location = new System.Drawing.Point(220, 109);
            this.populationLabel.Name = "populationLabel";
            this.populationLabel.Size = new System.Drawing.Size(85, 13);
            this.populationLabel.TabIndex = 4;
            this.populationLabel.Text = "1000000000000";
            // 
            // terrainLabel
            // 
            this.terrainLabel.AutoSize = true;
            this.terrainLabel.Location = new System.Drawing.Point(223, 52);
            this.terrainLabel.Name = "terrainLabel";
            this.terrainLabel.Size = new System.Drawing.Size(68, 13);
            this.terrainLabel.TabIndex = 5;
            this.terrainLabel.Text = "Mountainous";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(220, 9);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(49, 13);
            this.nameLabel.TabIndex = 6;
            this.nameLabel.Text = "Alderaan";
            // 
            // deathStar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 397);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.terrainLabel);
            this.Controls.Add(this.populationLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lackOfFaithButton);
            this.Name = "deathStar";
            this.Text = "Deatrh Star Laser Cannon";
            this.Load += new System.EventHandler(this.deathStar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button lackOfFaithButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label populationLabel;
        private System.Windows.Forms.Label terrainLabel;
        private System.Windows.Forms.Label nameLabel;
    }
}

