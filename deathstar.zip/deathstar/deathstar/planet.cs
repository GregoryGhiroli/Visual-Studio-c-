﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deathstar
{
    class planet
    {
        private string _planet;
        private decimal _pop;
        private string _land;


        public planet()
        {
            _planet ="Alderaan";
            _pop =  1000000000000m;
            _land ="Mountainous";

        }

        public string Planet
        {
            get { return _planet; }
            set {_planet = "Alderaan";}
        }
       
        public string Land
        {
            get { return _land; }
            set{ _land = "smithereens";}
        }
        public decimal Pop
        {
            get { return _pop; }
            set{ _pop = 0;}
        }
    }
}
