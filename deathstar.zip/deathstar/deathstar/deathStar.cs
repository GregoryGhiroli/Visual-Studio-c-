﻿/* Gregory Ghiroli
 * This program destorys worlds leaving billions of warm bodies floating in space, you monster
 * NACA 172.02
 * 12/4/14
 * 
 */ 



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deathstar
{
    public partial class deathStar : Form
    {
        public deathStar()
        {
            InitializeComponent();
        }
        private void activateDeathStar(planet force)
        {
            force.Planet = nameLabel.Text;
            force.Land = terrainLabel.Text;

            force.Pop = 1000000000000;


        }






        private void lackOfFaithButton_Click(object sender, EventArgs e)
        {
            planet myforce = new planet();

            activateDeathStar(myforce);
                 nameLabel.Text = myforce.Planet;
                terrainLabel.Text = myforce.Land;
                populationLabel.Text = myforce.Pop.ToString();

        }

        private void deathStar_Load(object sender, EventArgs e)
        {
             //apparently i can't get rid of this
        }
    }
}
