﻿/* Gregory Ghiroli
 * This program runs like an atm you put money in you get money out and it holds the rest
 * NACA 172.02
 * 12/4/14
 * 
 */ 




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bantAccountClass
{
    public partial class accountSimulator : Form
    {
        private BankAccount account = new BankAccount(1000);
        public accountSimulator()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void accountSimulator_Load(object sender, EventArgs e)
        {
            balanceLabel.Text = account.Balance.ToString("c");
        }

        private void depositButton_Click(object sender, EventArgs e)
        {
            decimal amount;


            if (decimal.TryParse(depositTextBox.Text, out amount))
            {
                account.Deposit(amount);

                balanceLabel.Text = account.Balance.ToString("c");

                depositTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Invalid amount");


            }
        }

        private void withdrawButton_Click(object sender, EventArgs e)
        {
            decimal amount;
            if (decimal.TryParse(withdrawTextBox.Text, out amount))
            {
                account.Withdraw(amount);

                balanceLabel.Text = account.Balance.ToString("c");

                withdrawTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Invalid amount");


            }
        }


        
       

       
    }
}
