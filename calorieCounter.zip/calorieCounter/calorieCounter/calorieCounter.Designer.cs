﻿namespace calorieCounter
{
    partial class calorieCounter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(calorieCounter));
            this.applePictureBox = new System.Windows.Forms.PictureBox();
            this.pearPictureBox = new System.Windows.Forms.PictureBox();
            this.orangePictureBox = new System.Windows.Forms.PictureBox();
            this.bananaPictureBox = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.outputTotalCalorieLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.applePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pearPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orangePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bananaPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // applePictureBox
            // 
            this.applePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("applePictureBox.Image")));
            this.applePictureBox.Location = new System.Drawing.Point(195, 34);
            this.applePictureBox.Name = "applePictureBox";
            this.applePictureBox.Size = new System.Drawing.Size(128, 150);
            this.applePictureBox.TabIndex = 0;
            this.applePictureBox.TabStop = false;
            this.applePictureBox.Click += new System.EventHandler(this.applePictureBox_Click);
            // 
            // pearPictureBox
            // 
            this.pearPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("pearPictureBox.Image")));
            this.pearPictureBox.Location = new System.Drawing.Point(195, 190);
            this.pearPictureBox.Name = "pearPictureBox";
            this.pearPictureBox.Size = new System.Drawing.Size(128, 156);
            this.pearPictureBox.TabIndex = 1;
            this.pearPictureBox.TabStop = false;
            this.pearPictureBox.Click += new System.EventHandler(this.pearPictureBox_Click);
            // 
            // orangePictureBox
            // 
            this.orangePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("orangePictureBox.Image")));
            this.orangePictureBox.Location = new System.Drawing.Point(59, 190);
            this.orangePictureBox.Name = "orangePictureBox";
            this.orangePictureBox.Size = new System.Drawing.Size(130, 156);
            this.orangePictureBox.TabIndex = 2;
            this.orangePictureBox.TabStop = false;
            this.orangePictureBox.Click += new System.EventHandler(this.orangePictureBox_Click);
            // 
            // bananaPictureBox
            // 
            this.bananaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("bananaPictureBox.Image")));
            this.bananaPictureBox.Location = new System.Drawing.Point(59, 34);
            this.bananaPictureBox.Name = "bananaPictureBox";
            this.bananaPictureBox.Size = new System.Drawing.Size(130, 150);
            this.bananaPictureBox.TabIndex = 3;
            this.bananaPictureBox.TabStop = false;
            this.bananaPictureBox.Click += new System.EventHandler(this.bananaPictureBox_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(391, 338);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(391, 300);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 5;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // outputTotalCalorieLabel
            // 
            this.outputTotalCalorieLabel.AutoSize = true;
            this.outputTotalCalorieLabel.Location = new System.Drawing.Point(395, 34);
            this.outputTotalCalorieLabel.Name = "outputTotalCalorieLabel";
            this.outputTotalCalorieLabel.Size = new System.Drawing.Size(71, 13);
            this.outputTotalCalorieLabel.TabIndex = 6;
            this.outputTotalCalorieLabel.Text = "Total Calories";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(395, 171);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(0, 13);
            this.totalLabel.TabIndex = 7;
            // 
            // calorieCounter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 386);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.outputTotalCalorieLabel);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.bananaPictureBox);
            this.Controls.Add(this.orangePictureBox);
            this.Controls.Add(this.pearPictureBox);
            this.Controls.Add(this.applePictureBox);
            this.Name = "calorieCounter";
            this.Text = "CalorieCounter";
            ((System.ComponentModel.ISupportInitialize)(this.applePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pearPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orangePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bananaPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox applePictureBox;
        private System.Windows.Forms.PictureBox pearPictureBox;
        private System.Windows.Forms.PictureBox orangePictureBox;
        private System.Windows.Forms.PictureBox bananaPictureBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label outputTotalCalorieLabel;
        private System.Windows.Forms.Label totalLabel;
    }
}

