﻿/* Gregory Ghiroli
 * 9/11/2014
 * NACA 160.02
 * This program counts calories of pictured fruit.
 */




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calorieCounter
{
    public partial class calorieCounter : Form
    {
        const decimal BANANA_VALUE = 115m;
        const decimal APPLE_VALUE = 80m;
        const decimal ORANGE_VALUE = 90m;
        const decimal PEAR_VALUE = 120m;

        private decimal total = 0m;

        public calorieCounter()
        {
            InitializeComponent();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            totalLabel.Text = "0 calories";
            total = 0m;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bananaPictureBox_Click(object sender, EventArgs e)
        {
            total += BANANA_VALUE;

            totalLabel.Text = total.ToString() + " calories";
        }

        private void applePictureBox_Click(object sender, EventArgs e)
        {
            total += APPLE_VALUE;

            totalLabel.Text = total.ToString() + " calories";
        }

        private void orangePictureBox_Click(object sender, EventArgs e)
        {
            total += ORANGE_VALUE;

            totalLabel.Text = total.ToString() + " calories";
        }

        private void pearPictureBox_Click(object sender, EventArgs e)
        {
            total += PEAR_VALUE;

            totalLabel.Text = total.ToString() + " calories";
        }
    }
}
