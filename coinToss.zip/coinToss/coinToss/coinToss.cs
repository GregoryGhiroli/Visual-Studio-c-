﻿/* Gregory Ghiroli
 * This program shows the coin side based on random results
 * 
 * NACA 160.02
 */ 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coinToss
{
    public partial class coinToss : Form
    {
        public coinToss()
        {
            InitializeComponent();
        }

        private void tossButton_Click(object sender, EventArgs e)
        {
            int sideUp;

            Random rand = new Random();

            sideUp = rand.Next(2);

            if (sideUp == 0)
            {
                tailsPictureBox.Visible = true;
                headsPictureBox.Visible = false;
            }
            else
            {
                tailsPictureBox.Visible = false;
                headsPictureBox.Visible = true;
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
