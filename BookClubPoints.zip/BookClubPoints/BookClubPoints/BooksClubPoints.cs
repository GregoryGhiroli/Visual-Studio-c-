﻿/* Gregory Ghiroli
 * NACA 16.02
 * 9/15/14
 * This program tells you how many points you have based on hoe many books you brought
 */



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookClubPoints
{
    public partial class BooksClubPoints : Form
    {
        public BooksClubPoints()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {

                decimal booksPurchased;
                booksPurchased = decimal.Parse(booksPurchasedTextBox.Text);

                if (booksPurchased <= 0)
                {
                    pointLabel.Text = " You have 0 points" + " from not buying any books";
                }
                else if (booksPurchased == 1)
                {
                    pointLabel.Text = " You have 5 points"+ " from buying 1 book";
                }
                else if (booksPurchased == 2)
                {
                    pointLabel.Text = " You have 15 points" + " from buying 2 books";
                }
                else if (booksPurchased == 3)
                {
                    pointLabel.Text = "You have 30 points" + " from buying 3 books";
                }
                else if (booksPurchased >= 4)
                {
                    pointLabel.Text = " You have 60 points" + " from buying 4 or more books";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            pointLabel.Text = "";
            booksPurchasedTextBox.Text = "";

            booksPurchasedTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
