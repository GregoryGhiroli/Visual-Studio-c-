﻿namespace BookClubPoints
{
    partial class BooksClubPoints
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.descriptionLAbel = new System.Windows.Forms.Label();
            this.pointLabel = new System.Windows.Forms.Label();
            this.outputLabelbookspurchased = new System.Windows.Forms.Label();
            this.booksPurchasedTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // descriptionLAbel
            // 
            this.descriptionLAbel.AutoSize = true;
            this.descriptionLAbel.Location = new System.Drawing.Point(62, 189);
            this.descriptionLAbel.Name = "descriptionLAbel";
            this.descriptionLAbel.Size = new System.Drawing.Size(142, 13);
            this.descriptionLAbel.TabIndex = 0;
            this.descriptionLAbel.Text = "From the books you brought:";
            // 
            // pointLabel
            // 
            this.pointLabel.AutoSize = true;
            this.pointLabel.Location = new System.Drawing.Point(224, 189);
            this.pointLabel.Name = "pointLabel";
            this.pointLabel.Size = new System.Drawing.Size(0, 13);
            this.pointLabel.TabIndex = 1;
            // 
            // outputLabelbookspurchased
            // 
            this.outputLabelbookspurchased.AutoSize = true;
            this.outputLabelbookspurchased.Location = new System.Drawing.Point(62, 71);
            this.outputLabelbookspurchased.Name = "outputLabelbookspurchased";
            this.outputLabelbookspurchased.Size = new System.Drawing.Size(137, 13);
            this.outputLabelbookspurchased.TabIndex = 2;
            this.outputLabelbookspurchased.Text = " number of book purchased";
            // 
            // booksPurchasedTextBox
            // 
            this.booksPurchasedTextBox.Location = new System.Drawing.Point(227, 68);
            this.booksPurchasedTextBox.Name = "booksPurchasedTextBox";
            this.booksPurchasedTextBox.Size = new System.Drawing.Size(100, 20);
            this.booksPurchasedTextBox.TabIndex = 3;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(22, 277);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(96, 23);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "CalculateButton";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(166, 277);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(308, 277);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // BooksClubPoints
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 337);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.booksPurchasedTextBox);
            this.Controls.Add(this.outputLabelbookspurchased);
            this.Controls.Add(this.pointLabel);
            this.Controls.Add(this.descriptionLAbel);
            this.Name = "BooksClubPoints";
            this.Text = "Book Club Points";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label descriptionLAbel;
        private System.Windows.Forms.Label pointLabel;
        private System.Windows.Forms.Label outputLabelbookspurchased;
        private System.Windows.Forms.TextBox booksPurchasedTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

