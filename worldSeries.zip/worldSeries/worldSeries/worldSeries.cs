﻿/*Gregory Ghiroli
 * This program tells the name of the team and how many world series that team won
 * NACA 160.02
 * 11/4/14
 */ 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace worldSeries
{
    public partial class worldSeries : Form
    {
        public worldSeries()
        {
            InitializeComponent();
        }

        string[] winsArray;

        private void teamListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // take the selected team and apply it to the world seires list
                string selectedTeam = teamListBox.SelectedItem.ToString();

                // Now that you know which team was selected, you would need to loop through the array from start to finish
                // and use an accumulator variable to count how many times this team won the World Series
                // Use the Baby Names project from last week to help with this assignment... 
                // you actually need to loop through this text file twice. First to get the size. Then declare the array's size. 
                // Then read the file again to populate your array with World Series Winners. 

                // Create StreamReader object  (you will need to ensure that using System.IO; is used)
                StreamReader inputFile;

                // Open text file with world series
                inputFile = File.OpenText("WorldSeries.txt");

                // Loop through worldseries file to count how many lines
                int num_of_lines = 0;
                while (!inputFile.EndOfStream)
                {
                    inputFile.ReadLine();
                    num_of_lines++;
                }

                // Now that we know how many names we have, the array could be initialized
                winsArray = new string[num_of_lines];
                // Re-open the file
                inputFile = File.OpenText("WorldSeries.txt");

                // Loop through world series names file again, this time to populate array
                int index = 0;
                while (index < winsArray.Length && !inputFile.EndOfStream)
                {
                    winsArray[index] = inputFile.ReadLine();
                    index++;
                }
                //  close the file
                inputFile.Close();


                int wins = 0;
                for (int i = 0; i < winsArray.Length; i++)
                {
                    if (winsArray[i] == selectedTeam)
                    {
                        wins += 1;

                    }
                    //
                }


                // also this last loop
                outputLabel.Text = selectedTeam + " has won " + wins + " times";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }





        }

        private void worldSeries_Load(object sender, EventArgs e)
        {
            try
            {
                //present teams text in listbox 
                string teams;

                StreamReader inputFile;

                inputFile = File.OpenText("Teams.txt");

                while (!inputFile.EndOfStream)
                {
                    teams = inputFile.ReadLine();
                    teamListBox.Items.Add(teams);
                }
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void outputLabel_Click(object sender, EventArgs e)
        {
        }
    }
}
