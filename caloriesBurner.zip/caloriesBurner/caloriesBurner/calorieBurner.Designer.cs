﻿namespace caloriesBurner
{
    partial class calorieBurner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.whileButton = new System.Windows.Forms.Button();
            this.forButton = new System.Windows.Forms.Button();
            this.doWhileButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // resultListBox
            // 
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.Location = new System.Drawing.Point(12, 18);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(407, 225);
            this.resultListBox.TabIndex = 0;
            // 
            // whileButton
            // 
            this.whileButton.Location = new System.Drawing.Point(13, 306);
            this.whileButton.Name = "whileButton";
            this.whileButton.Size = new System.Drawing.Size(75, 23);
            this.whileButton.TabIndex = 1;
            this.whileButton.Text = "While";
            this.whileButton.UseVisualStyleBackColor = true;
            this.whileButton.Click += new System.EventHandler(this.whileButton_Click);
            // 
            // forButton
            // 
            this.forButton.Location = new System.Drawing.Point(162, 305);
            this.forButton.Name = "forButton";
            this.forButton.Size = new System.Drawing.Size(75, 23);
            this.forButton.TabIndex = 2;
            this.forButton.Text = "For";
            this.forButton.UseVisualStyleBackColor = true;
            this.forButton.Click += new System.EventHandler(this.forButton_Click);
            // 
            // doWhileButton
            // 
            this.doWhileButton.Location = new System.Drawing.Point(305, 305);
            this.doWhileButton.Name = "doWhileButton";
            this.doWhileButton.Size = new System.Drawing.Size(75, 23);
            this.doWhileButton.TabIndex = 3;
            this.doWhileButton.Text = "Do while";
            this.doWhileButton.UseVisualStyleBackColor = true;
            this.doWhileButton.Click += new System.EventHandler(this.doWhileButton_Click);
            // 
            // calorieBurner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 351);
            this.Controls.Add(this.doWhileButton);
            this.Controls.Add(this.forButton);
            this.Controls.Add(this.whileButton);
            this.Controls.Add(this.resultListBox);
            this.Name = "calorieBurner";
            this.Text = "Calories Burner";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.Button whileButton;
        private System.Windows.Forms.Button forButton;
        private System.Windows.Forms.Button doWhileButton;
    }
}

