﻿/* Gregory Ghiroli
 * This program shows calroies burned per every 5 minutes with three commands
 * 10/2/14
 * 160.02
 */ 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace caloriesBurner
{
    public partial class calorieBurner : Form
    {
        public calorieBurner()
        {
            InitializeComponent();
        }

        private void whileButton_Click(object sender, EventArgs e)
        {

            const decimal calorie = 3.9m;
            int time = 30;
            int count = 10;
            decimal burned;
            resultListBox.Items.Clear();
            resultListBox.Items.Add("While  Loop"+ "/t");
            while (count <= time)
            {

                burned = (calorie * count);
                
                resultListBox.Items.Add(count + " time " + burned.ToString() + " calories burned");

                count = count + 5;
            }
           
        }

        private void forButton_Click(object sender, EventArgs e)
        {
              const decimal calorie = 3.9m;
            int time = 30;
           
            decimal burned;
            resultListBox.Items.Clear();
            resultListBox.Items.Add("For ");
            {
            
            
            for(  int count = 10 ; count<=time; count=count+5)
            {

                burned = (calorie * count);
                
                resultListBox.Items.Add(count + " time " + burned.ToString() + " calories burned");

                    }
                }
        }

        private void doWhileButton_Click(object sender, EventArgs e)
        {

            resultListBox.Items.Clear();
            const decimal calorie = 3.9m;
            int time = 30;
            int count = 10;
            decimal burned;
            resultListBox.Items.Add(" Do While ");
            do
            {


                burned = (calorie * count);
              
                resultListBox.Items.Add(count + " time " + burned.ToString() + " calories burned");

                count = count + 5;
            }

            while (count <= time);
        }
    }
}
