﻿namespace cupsToOunces
{
    partial class cupsToOunces
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.covertButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.descriptionLabelCups = new System.Windows.Forms.Label();
            this.descriptionLabelOunces = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cupsTextBox = new System.Windows.Forms.TextBox();
            this.ounceLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // covertButton
            // 
            this.covertButton.Location = new System.Drawing.Point(12, 226);
            this.covertButton.Name = "covertButton";
            this.covertButton.Size = new System.Drawing.Size(75, 23);
            this.covertButton.TabIndex = 0;
            this.covertButton.Text = "Convert";
            this.covertButton.UseVisualStyleBackColor = true;
            this.covertButton.Click += new System.EventHandler(this.covertButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(197, 226);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(75, 24);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(157, 13);
            this.descriptionLabel.TabIndex = 2;
            this.descriptionLabel.Text = "Cups to Fluid Ounces Converter";
            // 
            // descriptionLabelCups
            // 
            this.descriptionLabelCups.AutoSize = true;
            this.descriptionLabelCups.Location = new System.Drawing.Point(52, 88);
            this.descriptionLabelCups.Name = "descriptionLabelCups";
            this.descriptionLabelCups.Size = new System.Drawing.Size(31, 13);
            this.descriptionLabelCups.TabIndex = 3;
            this.descriptionLabelCups.Text = "Cups";
            // 
            // descriptionLabelOunces
            // 
            this.descriptionLabelOunces.AutoSize = true;
            this.descriptionLabelOunces.Location = new System.Drawing.Point(51, 174);
            this.descriptionLabelOunces.Name = "descriptionLabelOunces";
            this.descriptionLabelOunces.Size = new System.Drawing.Size(44, 13);
            this.descriptionLabelOunces.TabIndex = 4;
            this.descriptionLabelOunces.Text = "Ounces";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(197, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 5;
            // 
            // cupsTextBox
            // 
            this.cupsTextBox.Location = new System.Drawing.Point(197, 88);
            this.cupsTextBox.Name = "cupsTextBox";
            this.cupsTextBox.Size = new System.Drawing.Size(100, 20);
            this.cupsTextBox.TabIndex = 6;
            // 
            // ounceLabel
            // 
            this.ounceLabel.AutoSize = true;
            this.ounceLabel.Location = new System.Drawing.Point(197, 173);
            this.ounceLabel.Name = "ounceLabel";
            this.ounceLabel.Size = new System.Drawing.Size(35, 13);
            this.ounceLabel.TabIndex = 7;
            this.ounceLabel.Text = "label1";
            // 
            // cupsToOunces
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 261);
            this.Controls.Add(this.ounceLabel);
            this.Controls.Add(this.cupsTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.descriptionLabelOunces);
            this.Controls.Add(this.descriptionLabelCups);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.covertButton);
            this.Name = "cupsToOunces";
            this.Text = "Cups To Ounces";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button covertButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label descriptionLabelCups;
        private System.Windows.Forms.Label descriptionLabelOunces;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox cupsTextBox;
        private System.Windows.Forms.Label ounceLabel;
    }
}

