﻿/* Gregory Ghiroli
 * This program converts cups to ounces
 * NACA 160.02
 * 10/21/14
 * 
 */




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cupsToOunces
{
    public partial class cupsToOunces : Form
    {
        public cupsToOunces()
        {
            InitializeComponent();
        }

        private double CupsToOunces( double cups)
        {
            return cups * 8.0;
        }


        private void covertButton_Click(object sender, EventArgs e)
        {
            double cups, ounces;

            if(double.TryParse(cupsTextBox.Text, out cups))
            {
                ounces = CupsToOunces(cups);
                ounceLabel.Text = ounces.ToString("n1");
            }
            else
            {
                MessageBox.Show("enter a valid number");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
