﻿/* Gregory Ghrioli
 * This program counts the number of words
 * NACA 160.02
 * 11/11/14
 * 
 */ 





using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wordCounter
{
    public partial class wordCounter : Form
    {
        public wordCounter()
        {
            InitializeComponent();
        }

        private int count(string sentence)
        {
            int counts = 1;
            foreach (char ch in sentence)
                if (char.IsWhiteSpace(ch))
                {
                    counts++;
                }
            return counts;
        }
        private bool valid( int count)
        {
            bool valid;

            if (count >=1)
            {
                valid = true;
            }
            else
            {
                valid = false;
            }
            return valid;
       
        }


        private void countButton_Click(object sender, EventArgs e)
        {
            string sentence = wordTextBox.Text.Trim();
            int minlength = 0;
          
            if (sentence.Length > minlength) //valid theres input
            {

                if (valid( count(sentence)))
                {
                    resultLabel.Text = "Number of words: " + count(sentence);

                }
                else
                {
                    resultLabel.Text = " Number of words: 1";
                }

            }
            else
            {
                resultLabel.Text = " You didn't write anything";
            }

        }
    }
}
