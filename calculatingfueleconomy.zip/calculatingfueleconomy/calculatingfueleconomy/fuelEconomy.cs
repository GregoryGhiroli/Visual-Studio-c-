﻿/* Gregory Ghiroli
 * 9/23/14
 * This program calculates the mpg
 * NACA160.02
 * 
 */ 






using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatingfueleconomy
{
    public partial class fuelEconomy : Form
    {
        public fuelEconomy()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;
            double gallons;
            double mpg;

            if (double.TryParse(milesTextBox.Text, out miles))
            {
                if (double.TryParse(gallonsTextBox.Text, out gallons))
                {
                    mpg = miles / gallons;

                mpgLabel.Text = mpg.ToString("n1");
                }
                else
           
            {
                MessageBox.Show("Invalid input for gallons.");
            }
        }
            else
    {
        MessageBox.Show("Invalid input for miles.") ;
    }



        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
}
