﻿namespace calculatingfueleconomy
{
    partial class fuelEconomy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.milesDescriptionLabel = new System.Windows.Forms.Label();
            this.gallonsDescriptionLabel = new System.Windows.Forms.Label();
            this.mpgDescriptionLabel = new System.Windows.Forms.Label();
            this.mpgLabel = new System.Windows.Forms.Label();
            this.milesTextBox = new System.Windows.Forms.TextBox();
            this.gallonsTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(264, 339);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 43);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(52, 339);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 43);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate MPG";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // milesDescriptionLabel
            // 
            this.milesDescriptionLabel.AutoSize = true;
            this.milesDescriptionLabel.Location = new System.Drawing.Point(49, 60);
            this.milesDescriptionLabel.Name = "milesDescriptionLabel";
            this.milesDescriptionLabel.Size = new System.Drawing.Size(158, 13);
            this.milesDescriptionLabel.TabIndex = 2;
            this.milesDescriptionLabel.Text = "Enter the number of miles driven";
            // 
            // gallonsDescriptionLabel
            // 
            this.gallonsDescriptionLabel.AutoSize = true;
            this.gallonsDescriptionLabel.Location = new System.Drawing.Point(49, 143);
            this.gallonsDescriptionLabel.Name = "gallonsDescriptionLabel";
            this.gallonsDescriptionLabel.Size = new System.Drawing.Size(144, 13);
            this.gallonsDescriptionLabel.TabIndex = 3;
            this.gallonsDescriptionLabel.Text = "Enter the gallons of gas used";
            // 
            // mpgDescriptionLabel
            // 
            this.mpgDescriptionLabel.AutoSize = true;
            this.mpgDescriptionLabel.Location = new System.Drawing.Point(52, 246);
            this.mpgDescriptionLabel.Name = "mpgDescriptionLabel";
            this.mpgDescriptionLabel.Size = new System.Drawing.Size(81, 13);
            this.mpgDescriptionLabel.TabIndex = 4;
            this.mpgDescriptionLabel.Text = "Your car\'s MPG";
            // 
            // mpgLabel
            // 
            this.mpgLabel.AutoSize = true;
            this.mpgLabel.Location = new System.Drawing.Point(261, 246);
            this.mpgLabel.Name = "mpgLabel";
            this.mpgLabel.Size = new System.Drawing.Size(0, 13);
            this.mpgLabel.TabIndex = 5;
            // 
            // milesTextBox
            // 
            this.milesTextBox.Location = new System.Drawing.Point(264, 60);
            this.milesTextBox.Name = "milesTextBox";
            this.milesTextBox.Size = new System.Drawing.Size(100, 20);
            this.milesTextBox.TabIndex = 6;
            // 
            // gallonsTextBox
            // 
            this.gallonsTextBox.Location = new System.Drawing.Point(264, 135);
            this.gallonsTextBox.Name = "gallonsTextBox";
            this.gallonsTextBox.Size = new System.Drawing.Size(100, 20);
            this.gallonsTextBox.TabIndex = 7;
            // 
            // fuelEconomy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 394);
            this.Controls.Add(this.gallonsTextBox);
            this.Controls.Add(this.milesTextBox);
            this.Controls.Add(this.mpgLabel);
            this.Controls.Add(this.mpgDescriptionLabel);
            this.Controls.Add(this.gallonsDescriptionLabel);
            this.Controls.Add(this.milesDescriptionLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Name = "fuelEconomy";
            this.Text = "Fuel Economy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label milesDescriptionLabel;
        private System.Windows.Forms.Label gallonsDescriptionLabel;
        private System.Windows.Forms.Label mpgDescriptionLabel;
        private System.Windows.Forms.Label mpgLabel;
        private System.Windows.Forms.TextBox milesTextBox;
        private System.Windows.Forms.TextBox gallonsTextBox;
    }
}

