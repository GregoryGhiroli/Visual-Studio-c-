﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carClass
{
    class Car
    {
        private string _year;
        private string _model;
        private int _sped = 0;

         public Car()
        {
            _year = "";
            _sped = 0;
            _model = "";
        }
         public string Model
         {
             get { return _model; }
             set { _model = value; }
         }

         public int Speed   // display integer
         {
             get { return _sped; }
             set { _sped = value; }
         }
        

         public string Year
         {
             get { return _year; }
             set { _year = value; }
         }


         // Methods
         public void Accelerate()
         {
             _sped = _sped + 5;
         }
         public void Brake()
         {
             if (_sped > 5)
             {
                 _sped = _sped - 5;
             }
             else
             {
                 _sped = 0;
             }
         }




         
    }
}
