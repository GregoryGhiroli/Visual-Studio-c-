﻿/*Gregory Ghiroli
 * This program tells you about a car speeding and braking
 * NACA 172.02
 * 12/2/14
 */ 



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carClass
{
    public partial class carClass : Form
    {
        public carClass()
        {
            InitializeComponent();
        }
        Car myCar = new Car();
        private void DisplayCarInfo(Car car)
        {
            displayLabel.Text = "A "+car.Model + " from " + car. Year +
                 " is going " + car.Speed+" mph";
            // i screwed uo the word speed so were wrking with sped now
        }

        private void speedButton_Click(object sender, EventArgs e)
        {
           
            myCar.Year = yearTextBox.Text;

            myCar.Model = modelTextBox.Text;

            myCar.Accelerate();
          

            DisplayCarInfo(myCar);

        }

        private void BrakeButton_Click(object sender, EventArgs e)
        {
            myCar.Model = modelTextBox.Text;
            myCar.Year = yearTextBox.Text;

         
            myCar.Brake();

            DisplayCarInfo(myCar);
        }




    }
}
