﻿/* Gregory Ghiroli
 * Ok this program is suppose to draw triangle up and down.
 * NACA 160.02
 * 
 * 
 */ 




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrawTriangles
{
    public partial class drawTriangles : Form
    {
        public drawTriangles()
        {
            InitializeComponent();
        }

        private void upButton_Click(object sender, EventArgs e)
        {
            int n;
            resultListBox.Items.Clear();
            string symbol = "";
            {

                if (int.TryParse(triangleTextBox.Text, out n))
                {
                    if (n <= 10 && n > 0)
                    {
                        for (int i = 1; i <= n; i++)
                        {

                            for (int j = i; j <= i; j++)
                            {
                                symbol = symbol + "X";

                                resultListBox.Items.Add(symbol);
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show(" invalid number, pick a number between 1-10");
                    }
                }
                    else
                {
                    MessageBox.Show(" invalid input, pick a number between 1-10");

                }
            }



        }

        private void downButton_Click(object sender, EventArgs e)
        {
            int n;
            resultListBox.Items.Clear();
            string symbol = "";
            {

                if (int.TryParse(triangleTextBox.Text, out n))
                {
                    if (n <= 10 && n > 0)
                    {
                        for (int i = n; i >= 1; i ++)
                        {
                            for (int j = n; j <= i; j++)
                            {
                                symbol = symbol + "X";

                                resultListBox.Items.Add(symbol);
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show(" invalid number, pick a number between 1-10");
                    }
                }
                    else
                {
                    MessageBox.Show(" invalid input, pick a number between 1-10");

                }


                }
            }
        }
    } 