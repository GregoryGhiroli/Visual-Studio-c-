﻿using System;
/*Gregory Ghiroli
 * 10/14/14
 * NACA160.02
 * This program shows the card selected in the listbox by name
 */ 





using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cards
{
    public partial class Cards : Form
    {
        public Cards()
        {
            InitializeComponent();
        }

        private void ShowCard(string card)
        {
            switch (card)
            {
                case "Ace of Spades":
                    ShowAceSpades();
                    break;
                case "10 of Hearts":
                    ShowTenHearts();
                    break;
                case "King of Clubs":
                    ShowKingClubs();
                    break;
            }

        }
        private void ShowAceSpades()
        {
            aceSpadesPictureBox.Visible = true;
            TenHeartsPictureBox.Visible = false;
            kingClubsPictureBox.Visible = false;
        }
        private void ShowTenHearts()
        {
            aceSpadesPictureBox.Visible = false;
            TenHeartsPictureBox.Visible = true;
            kingClubsPictureBox.Visible = false;
        }
        private void ShowKingClubs()
        {
            aceSpadesPictureBox.Visible = false;
            TenHeartsPictureBox.Visible = false;
            kingClubsPictureBox.Visible = true;
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void showCardButton_Click(object sender, EventArgs e)
        {
            if (cardListBox.SelectedIndex != -1)
            {
                ShowCard(cardListBox.SelectedItem.ToString());
            }
            else
            {
                MessageBox.Show(" Please select a card from" + " the list box ");
            }
        }
    }
}
