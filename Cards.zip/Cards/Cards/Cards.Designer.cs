﻿namespace Cards
{
    partial class Cards
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cards));
            this.showCardButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.cardListBox = new System.Windows.Forms.ListBox();
            this.aceSpadesPictureBox = new System.Windows.Forms.PictureBox();
            this.TenHeartsPictureBox = new System.Windows.Forms.PictureBox();
            this.kingClubsPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.aceSpadesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TenHeartsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingClubsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // showCardButton
            // 
            this.showCardButton.Location = new System.Drawing.Point(37, 426);
            this.showCardButton.Name = "showCardButton";
            this.showCardButton.Size = new System.Drawing.Size(75, 23);
            this.showCardButton.TabIndex = 0;
            this.showCardButton.Text = "Show Card";
            this.showCardButton.UseVisualStyleBackColor = true;
            this.showCardButton.Click += new System.EventHandler(this.showCardButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(313, 426);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // cardListBox
            // 
            this.cardListBox.FormattingEnabled = true;
            this.cardListBox.Items.AddRange(new object[] {
            "Ace of Spades",
            "10 of Hearts",
            "King of Clubs"});
            this.cardListBox.Location = new System.Drawing.Point(154, 299);
            this.cardListBox.Name = "cardListBox";
            this.cardListBox.Size = new System.Drawing.Size(120, 95);
            this.cardListBox.TabIndex = 2;
            // 
            // aceSpadesPictureBox
            // 
            this.aceSpadesPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("aceSpadesPictureBox.Image")));
            this.aceSpadesPictureBox.Location = new System.Drawing.Point(12, 38);
            this.aceSpadesPictureBox.Name = "aceSpadesPictureBox";
            this.aceSpadesPictureBox.Size = new System.Drawing.Size(100, 169);
            this.aceSpadesPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceSpadesPictureBox.TabIndex = 3;
            this.aceSpadesPictureBox.TabStop = false;
            // 
            // TenHeartsPictureBox
            // 
            this.TenHeartsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("TenHeartsPictureBox.Image")));
            this.TenHeartsPictureBox.Location = new System.Drawing.Point(164, 38);
            this.TenHeartsPictureBox.Name = "TenHeartsPictureBox";
            this.TenHeartsPictureBox.Size = new System.Drawing.Size(100, 169);
            this.TenHeartsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TenHeartsPictureBox.TabIndex = 4;
            this.TenHeartsPictureBox.TabStop = false;
            // 
            // kingClubsPictureBox
            // 
            this.kingClubsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("kingClubsPictureBox.Image")));
            this.kingClubsPictureBox.Location = new System.Drawing.Point(313, 38);
            this.kingClubsPictureBox.Name = "kingClubsPictureBox";
            this.kingClubsPictureBox.Size = new System.Drawing.Size(100, 169);
            this.kingClubsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kingClubsPictureBox.TabIndex = 5;
            this.kingClubsPictureBox.TabStop = false;
            // 
            // Cards
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 461);
            this.Controls.Add(this.kingClubsPictureBox);
            this.Controls.Add(this.TenHeartsPictureBox);
            this.Controls.Add(this.aceSpadesPictureBox);
            this.Controls.Add(this.cardListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showCardButton);
            this.Name = "Cards";
            this.Text = "Cards";
            ((System.ComponentModel.ISupportInitialize)(this.aceSpadesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TenHeartsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingClubsPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showCardButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox cardListBox;
        private System.Windows.Forms.PictureBox aceSpadesPictureBox;
        private System.Windows.Forms.PictureBox TenHeartsPictureBox;
        private System.Windows.Forms.PictureBox kingClubsPictureBox;
    }
}

