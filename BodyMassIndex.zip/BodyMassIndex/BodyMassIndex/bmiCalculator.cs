﻿/* Gregory Ghiroli
 * NACA.02
 * 9/11/14
 * This program calculates your BMI
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BodyMassIndex
{
    public partial class BMICalculator : Form
    {
        public BMICalculator()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double weight;
                double height;
                double bmi;
                weight = double.Parse(weightTextBox.Text);
                height = double.Parse(heightTextBox.Text);

                bmi = (weight * 703) / (height * height);

                bmiLabel.Text = bmi.ToString("n1");
            }
            catch (Exception ex)
            {
                MessageBox.Show (ex.Message);
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            weightTextBox.Text = "";
            heightTextBox.Text = "";
            bmiLabel.Text = "";
        }
    }
}
