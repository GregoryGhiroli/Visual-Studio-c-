﻿namespace drinkVendingMachine
{
    partial class drinkVendingMachine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(drinkVendingMachine));
            this.exitButton = new System.Windows.Forms.Button();
            this.totalSalesPanel = new System.Windows.Forms.Panel();
            this.totalResultLabel = new System.Windows.Forms.Label();
            this.totalSalesLabel = new System.Windows.Forms.Label();
            this.grapeSodaPanel = new System.Windows.Forms.Panel();
            this.grapeSodasRemainingLabel = new System.Windows.Forms.Label();
            this.drinksLeftLabel4 = new System.Windows.Forms.Label();
            this.grapeSodaCostLabel = new System.Windows.Forms.Label();
            this.grapeSodaPictureBox = new System.Windows.Forms.PictureBox();
            this.rootBeerPanel = new System.Windows.Forms.Panel();
            this.rootBeersRemainingLabel = new System.Windows.Forms.Label();
            this.drinksLeftLabel2 = new System.Windows.Forms.Label();
            this.rootBeerCostLabel = new System.Windows.Forms.Label();
            this.rootBeerPictureBox = new System.Windows.Forms.PictureBox();
            this.creamSodaPanel = new System.Windows.Forms.Panel();
            this.creamSodasRemainingLabel = new System.Windows.Forms.Label();
            this.drinksLeftLabel5 = new System.Windows.Forms.Label();
            this.creamSodaCostLabel = new System.Windows.Forms.Label();
            this.creamSodaPictureBox = new System.Windows.Forms.PictureBox();
            this.lemonLimePanel = new System.Windows.Forms.Panel();
            this.lemonLimeSodasRemainingLabel = new System.Windows.Forms.Label();
            this.drinksLeftLabel3 = new System.Windows.Forms.Label();
            this.lemonLimeCostLabel = new System.Windows.Forms.Label();
            this.lemonLimePictureBox = new System.Windows.Forms.PictureBox();
            this.cocaColaPanel = new System.Windows.Forms.Panel();
            this.colaPictureBox = new System.Windows.Forms.PictureBox();
            this.colasRemainingLabel = new System.Windows.Forms.Label();
            this.drinksLeftLabel1 = new System.Windows.Forms.Label();
            this.colaCostLabel = new System.Windows.Forms.Label();
            this.selectDrinkLabel = new System.Windows.Forms.Label();
            this.totalSalesPanel.SuspendLayout();
            this.grapeSodaPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grapeSodaPictureBox)).BeginInit();
            this.rootBeerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rootBeerPictureBox)).BeginInit();
            this.creamSodaPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.creamSodaPictureBox)).BeginInit();
            this.lemonLimePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lemonLimePictureBox)).BeginInit();
            this.cocaColaPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colaPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(130, 306);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 22;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // totalSalesPanel
            // 
            this.totalSalesPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalSalesPanel.Controls.Add(this.totalResultLabel);
            this.totalSalesPanel.Controls.Add(this.totalSalesLabel);
            this.totalSalesPanel.Location = new System.Drawing.Point(165, 224);
            this.totalSalesPanel.Name = "totalSalesPanel";
            this.totalSalesPanel.Size = new System.Drawing.Size(158, 76);
            this.totalSalesPanel.TabIndex = 21;
            // 
            // totalResultLabel
            // 
            this.totalResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalResultLabel.Location = new System.Drawing.Point(48, 38);
            this.totalResultLabel.Name = "totalResultLabel";
            this.totalResultLabel.Size = new System.Drawing.Size(68, 23);
            this.totalResultLabel.TabIndex = 4;
            this.totalResultLabel.Text = "$0.00";
            this.totalResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalSalesLabel
            // 
            this.totalSalesLabel.AutoSize = true;
            this.totalSalesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalSalesLabel.Location = new System.Drawing.Point(45, 10);
            this.totalSalesLabel.Name = "totalSalesLabel";
            this.totalSalesLabel.Size = new System.Drawing.Size(71, 13);
            this.totalSalesLabel.TabIndex = 1;
            this.totalSalesLabel.Text = "Total Sales";
            // 
            // grapeSodaPanel
            // 
            this.grapeSodaPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grapeSodaPanel.Controls.Add(this.grapeSodasRemainingLabel);
            this.grapeSodaPanel.Controls.Add(this.drinksLeftLabel4);
            this.grapeSodaPanel.Controls.Add(this.grapeSodaCostLabel);
            this.grapeSodaPanel.Controls.Add(this.grapeSodaPictureBox);
            this.grapeSodaPanel.Location = new System.Drawing.Point(165, 142);
            this.grapeSodaPanel.Name = "grapeSodaPanel";
            this.grapeSodaPanel.Size = new System.Drawing.Size(158, 76);
            this.grapeSodaPanel.TabIndex = 20;
            // 
            // grapeSodasRemainingLabel
            // 
            this.grapeSodasRemainingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.grapeSodasRemainingLabel.Location = new System.Drawing.Point(88, 38);
            this.grapeSodasRemainingLabel.Name = "grapeSodasRemainingLabel";
            this.grapeSodasRemainingLabel.Size = new System.Drawing.Size(58, 23);
            this.grapeSodasRemainingLabel.TabIndex = 3;
            this.grapeSodasRemainingLabel.Text = "20";
            this.grapeSodasRemainingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // drinksLeftLabel4
            // 
            this.drinksLeftLabel4.AutoSize = true;
            this.drinksLeftLabel4.Location = new System.Drawing.Point(85, 21);
            this.drinksLeftLabel4.Name = "drinksLeftLabel4";
            this.drinksLeftLabel4.Size = new System.Drawing.Size(61, 13);
            this.drinksLeftLabel4.TabIndex = 2;
            this.drinksLeftLabel4.Text = "Drinks Left:";
            // 
            // grapeSodaCostLabel
            // 
            this.grapeSodaCostLabel.AutoSize = true;
            this.grapeSodaCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grapeSodaCostLabel.Location = new System.Drawing.Point(91, 4);
            this.grapeSodaCostLabel.Name = "grapeSodaCostLabel";
            this.grapeSodaCostLabel.Size = new System.Drawing.Size(39, 13);
            this.grapeSodaCostLabel.TabIndex = 1;
            this.grapeSodaCostLabel.Text = "$1.50";
            // 
            // grapeSodaPictureBox
            // 
            this.grapeSodaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("grapeSodaPictureBox.Image")));
            this.grapeSodaPictureBox.Location = new System.Drawing.Point(4, 4);
            this.grapeSodaPictureBox.Name = "grapeSodaPictureBox";
            this.grapeSodaPictureBox.Size = new System.Drawing.Size(62, 64);
            this.grapeSodaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grapeSodaPictureBox.TabIndex = 0;
            this.grapeSodaPictureBox.TabStop = false;
            this.grapeSodaPictureBox.Click += new System.EventHandler(this.grapeSodaPictureBox_Click);
            // 
            // rootBeerPanel
            // 
            this.rootBeerPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rootBeerPanel.Controls.Add(this.rootBeersRemainingLabel);
            this.rootBeerPanel.Controls.Add(this.drinksLeftLabel2);
            this.rootBeerPanel.Controls.Add(this.rootBeerCostLabel);
            this.rootBeerPanel.Controls.Add(this.rootBeerPictureBox);
            this.rootBeerPanel.Location = new System.Drawing.Point(165, 60);
            this.rootBeerPanel.Name = "rootBeerPanel";
            this.rootBeerPanel.Size = new System.Drawing.Size(158, 76);
            this.rootBeerPanel.TabIndex = 19;
            // 
            // rootBeersRemainingLabel
            // 
            this.rootBeersRemainingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rootBeersRemainingLabel.Location = new System.Drawing.Point(88, 38);
            this.rootBeersRemainingLabel.Name = "rootBeersRemainingLabel";
            this.rootBeersRemainingLabel.Size = new System.Drawing.Size(58, 23);
            this.rootBeersRemainingLabel.TabIndex = 3;
            this.rootBeersRemainingLabel.Text = "20";
            this.rootBeersRemainingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // drinksLeftLabel2
            // 
            this.drinksLeftLabel2.AutoSize = true;
            this.drinksLeftLabel2.Location = new System.Drawing.Point(85, 21);
            this.drinksLeftLabel2.Name = "drinksLeftLabel2";
            this.drinksLeftLabel2.Size = new System.Drawing.Size(61, 13);
            this.drinksLeftLabel2.TabIndex = 2;
            this.drinksLeftLabel2.Text = "Drinks Left:";
            // 
            // rootBeerCostLabel
            // 
            this.rootBeerCostLabel.AutoSize = true;
            this.rootBeerCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rootBeerCostLabel.Location = new System.Drawing.Point(91, 4);
            this.rootBeerCostLabel.Name = "rootBeerCostLabel";
            this.rootBeerCostLabel.Size = new System.Drawing.Size(39, 13);
            this.rootBeerCostLabel.TabIndex = 1;
            this.rootBeerCostLabel.Text = "$1.00";
            // 
            // rootBeerPictureBox
            // 
            this.rootBeerPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("rootBeerPictureBox.Image")));
            this.rootBeerPictureBox.Location = new System.Drawing.Point(4, 4);
            this.rootBeerPictureBox.Name = "rootBeerPictureBox";
            this.rootBeerPictureBox.Size = new System.Drawing.Size(64, 64);
            this.rootBeerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.rootBeerPictureBox.TabIndex = 0;
            this.rootBeerPictureBox.TabStop = false;
            this.rootBeerPictureBox.Click += new System.EventHandler(this.rootBeerPictureBox_Click);
            // 
            // creamSodaPanel
            // 
            this.creamSodaPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.creamSodaPanel.Controls.Add(this.creamSodasRemainingLabel);
            this.creamSodaPanel.Controls.Add(this.drinksLeftLabel5);
            this.creamSodaPanel.Controls.Add(this.creamSodaCostLabel);
            this.creamSodaPanel.Controls.Add(this.creamSodaPictureBox);
            this.creamSodaPanel.Location = new System.Drawing.Point(1, 224);
            this.creamSodaPanel.Name = "creamSodaPanel";
            this.creamSodaPanel.Size = new System.Drawing.Size(158, 76);
            this.creamSodaPanel.TabIndex = 18;
            // 
            // creamSodasRemainingLabel
            // 
            this.creamSodasRemainingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.creamSodasRemainingLabel.Location = new System.Drawing.Point(88, 38);
            this.creamSodasRemainingLabel.Name = "creamSodasRemainingLabel";
            this.creamSodasRemainingLabel.Size = new System.Drawing.Size(58, 23);
            this.creamSodasRemainingLabel.TabIndex = 3;
            this.creamSodasRemainingLabel.Text = "20";
            this.creamSodasRemainingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // drinksLeftLabel5
            // 
            this.drinksLeftLabel5.AutoSize = true;
            this.drinksLeftLabel5.Location = new System.Drawing.Point(85, 21);
            this.drinksLeftLabel5.Name = "drinksLeftLabel5";
            this.drinksLeftLabel5.Size = new System.Drawing.Size(61, 13);
            this.drinksLeftLabel5.TabIndex = 2;
            this.drinksLeftLabel5.Text = "Drinks Left:";
            // 
            // creamSodaCostLabel
            // 
            this.creamSodaCostLabel.AutoSize = true;
            this.creamSodaCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creamSodaCostLabel.Location = new System.Drawing.Point(91, 4);
            this.creamSodaCostLabel.Name = "creamSodaCostLabel";
            this.creamSodaCostLabel.Size = new System.Drawing.Size(39, 13);
            this.creamSodaCostLabel.TabIndex = 1;
            this.creamSodaCostLabel.Text = "$1.50";
            // 
            // creamSodaPictureBox
            // 
            this.creamSodaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("creamSodaPictureBox.Image")));
            this.creamSodaPictureBox.Location = new System.Drawing.Point(4, 4);
            this.creamSodaPictureBox.Name = "creamSodaPictureBox";
            this.creamSodaPictureBox.Size = new System.Drawing.Size(62, 64);
            this.creamSodaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.creamSodaPictureBox.TabIndex = 0;
            this.creamSodaPictureBox.TabStop = false;
            this.creamSodaPictureBox.Click += new System.EventHandler(this.creamSodaPictureBox_Click);
            // 
            // lemonLimePanel
            // 
            this.lemonLimePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lemonLimePanel.Controls.Add(this.lemonLimeSodasRemainingLabel);
            this.lemonLimePanel.Controls.Add(this.drinksLeftLabel3);
            this.lemonLimePanel.Controls.Add(this.lemonLimeCostLabel);
            this.lemonLimePanel.Controls.Add(this.lemonLimePictureBox);
            this.lemonLimePanel.Location = new System.Drawing.Point(1, 142);
            this.lemonLimePanel.Name = "lemonLimePanel";
            this.lemonLimePanel.Size = new System.Drawing.Size(158, 76);
            this.lemonLimePanel.TabIndex = 17;
            // 
            // lemonLimeSodasRemainingLabel
            // 
            this.lemonLimeSodasRemainingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lemonLimeSodasRemainingLabel.Location = new System.Drawing.Point(88, 38);
            this.lemonLimeSodasRemainingLabel.Name = "lemonLimeSodasRemainingLabel";
            this.lemonLimeSodasRemainingLabel.Size = new System.Drawing.Size(58, 23);
            this.lemonLimeSodasRemainingLabel.TabIndex = 3;
            this.lemonLimeSodasRemainingLabel.Text = "20";
            this.lemonLimeSodasRemainingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // drinksLeftLabel3
            // 
            this.drinksLeftLabel3.AutoSize = true;
            this.drinksLeftLabel3.Location = new System.Drawing.Point(85, 21);
            this.drinksLeftLabel3.Name = "drinksLeftLabel3";
            this.drinksLeftLabel3.Size = new System.Drawing.Size(61, 13);
            this.drinksLeftLabel3.TabIndex = 2;
            this.drinksLeftLabel3.Text = "Drinks Left:";
            // 
            // lemonLimeCostLabel
            // 
            this.lemonLimeCostLabel.AutoSize = true;
            this.lemonLimeCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lemonLimeCostLabel.Location = new System.Drawing.Point(91, 4);
            this.lemonLimeCostLabel.Name = "lemonLimeCostLabel";
            this.lemonLimeCostLabel.Size = new System.Drawing.Size(39, 13);
            this.lemonLimeCostLabel.TabIndex = 1;
            this.lemonLimeCostLabel.Text = "$1.00";
            // 
            // lemonLimePictureBox
            // 
            this.lemonLimePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("lemonLimePictureBox.Image")));
            this.lemonLimePictureBox.Location = new System.Drawing.Point(4, 4);
            this.lemonLimePictureBox.Name = "lemonLimePictureBox";
            this.lemonLimePictureBox.Size = new System.Drawing.Size(62, 64);
            this.lemonLimePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.lemonLimePictureBox.TabIndex = 0;
            this.lemonLimePictureBox.TabStop = false;
            this.lemonLimePictureBox.Click += new System.EventHandler(this.lemonLimePictureBox_Click);
            // 
            // cocaColaPanel
            // 
            this.cocaColaPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cocaColaPanel.Controls.Add(this.colaPictureBox);
            this.cocaColaPanel.Controls.Add(this.colasRemainingLabel);
            this.cocaColaPanel.Controls.Add(this.drinksLeftLabel1);
            this.cocaColaPanel.Controls.Add(this.colaCostLabel);
            this.cocaColaPanel.Location = new System.Drawing.Point(1, 60);
            this.cocaColaPanel.Name = "cocaColaPanel";
            this.cocaColaPanel.Size = new System.Drawing.Size(158, 76);
            this.cocaColaPanel.TabIndex = 16;
            // 
            // colaPictureBox
            // 
            this.colaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("colaPictureBox.Image")));
            this.colaPictureBox.Location = new System.Drawing.Point(9, 5);
            this.colaPictureBox.Name = "colaPictureBox";
            this.colaPictureBox.Size = new System.Drawing.Size(64, 64);
            this.colaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.colaPictureBox.TabIndex = 4;
            this.colaPictureBox.TabStop = false;
            this.colaPictureBox.Click += new System.EventHandler(this.colaPictureBox_Click);
            // 
            // colasRemainingLabel
            // 
            this.colasRemainingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.colasRemainingLabel.Location = new System.Drawing.Point(88, 38);
            this.colasRemainingLabel.Name = "colasRemainingLabel";
            this.colasRemainingLabel.Size = new System.Drawing.Size(58, 23);
            this.colasRemainingLabel.TabIndex = 3;
            this.colasRemainingLabel.Text = "20";
            this.colasRemainingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // drinksLeftLabel1
            // 
            this.drinksLeftLabel1.AutoSize = true;
            this.drinksLeftLabel1.Location = new System.Drawing.Point(85, 21);
            this.drinksLeftLabel1.Name = "drinksLeftLabel1";
            this.drinksLeftLabel1.Size = new System.Drawing.Size(61, 13);
            this.drinksLeftLabel1.TabIndex = 2;
            this.drinksLeftLabel1.Text = "Drinks Left:";
            // 
            // colaCostLabel
            // 
            this.colaCostLabel.AutoSize = true;
            this.colaCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colaCostLabel.Location = new System.Drawing.Point(97, 4);
            this.colaCostLabel.Name = "colaCostLabel";
            this.colaCostLabel.Size = new System.Drawing.Size(39, 13);
            this.colaCostLabel.TabIndex = 1;
            this.colaCostLabel.Text = "$1.00";
            // 
            // selectDrinkLabel
            // 
            this.selectDrinkLabel.AutoSize = true;
            this.selectDrinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectDrinkLabel.Location = new System.Drawing.Point(111, 29);
            this.selectDrinkLabel.Name = "selectDrinkLabel";
            this.selectDrinkLabel.Size = new System.Drawing.Size(122, 20);
            this.selectDrinkLabel.TabIndex = 15;
            this.selectDrinkLabel.Text = "Select a Drink";
            // 
            // drinkVendingMachine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 358);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.totalSalesPanel);
            this.Controls.Add(this.grapeSodaPanel);
            this.Controls.Add(this.rootBeerPanel);
            this.Controls.Add(this.creamSodaPanel);
            this.Controls.Add(this.lemonLimePanel);
            this.Controls.Add(this.cocaColaPanel);
            this.Controls.Add(this.selectDrinkLabel);
            this.Name = "drinkVendingMachine";
            this.Text = "Drink Vending Machine";
            this.totalSalesPanel.ResumeLayout(false);
            this.totalSalesPanel.PerformLayout();
            this.grapeSodaPanel.ResumeLayout(false);
            this.grapeSodaPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grapeSodaPictureBox)).EndInit();
            this.rootBeerPanel.ResumeLayout(false);
            this.rootBeerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rootBeerPictureBox)).EndInit();
            this.creamSodaPanel.ResumeLayout(false);
            this.creamSodaPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.creamSodaPictureBox)).EndInit();
            this.lemonLimePanel.ResumeLayout(false);
            this.lemonLimePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lemonLimePictureBox)).EndInit();
            this.cocaColaPanel.ResumeLayout(false);
            this.cocaColaPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colaPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Panel totalSalesPanel;
        private System.Windows.Forms.Label totalSalesLabel;
        private System.Windows.Forms.Panel grapeSodaPanel;
        private System.Windows.Forms.Label grapeSodasRemainingLabel;
        private System.Windows.Forms.Label drinksLeftLabel4;
        private System.Windows.Forms.Label grapeSodaCostLabel;
        private System.Windows.Forms.PictureBox grapeSodaPictureBox;
        private System.Windows.Forms.Panel rootBeerPanel;
        private System.Windows.Forms.Label rootBeersRemainingLabel;
        private System.Windows.Forms.Label drinksLeftLabel2;
        private System.Windows.Forms.Label rootBeerCostLabel;
        private System.Windows.Forms.PictureBox rootBeerPictureBox;
        private System.Windows.Forms.Panel creamSodaPanel;
        private System.Windows.Forms.Label creamSodasRemainingLabel;
        private System.Windows.Forms.Label drinksLeftLabel5;
        private System.Windows.Forms.Label creamSodaCostLabel;
        private System.Windows.Forms.PictureBox creamSodaPictureBox;
        private System.Windows.Forms.Panel lemonLimePanel;
        private System.Windows.Forms.Label lemonLimeSodasRemainingLabel;
        private System.Windows.Forms.Label drinksLeftLabel3;
        private System.Windows.Forms.Label lemonLimeCostLabel;
        private System.Windows.Forms.PictureBox lemonLimePictureBox;
        private System.Windows.Forms.Panel cocaColaPanel;
        private System.Windows.Forms.Label colasRemainingLabel;
        private System.Windows.Forms.Label drinksLeftLabel1;
        private System.Windows.Forms.Label colaCostLabel;
        private System.Windows.Forms.Label selectDrinkLabel;
        private System.Windows.Forms.Label totalResultLabel;
        private System.Windows.Forms.PictureBox colaPictureBox;
    }
}

