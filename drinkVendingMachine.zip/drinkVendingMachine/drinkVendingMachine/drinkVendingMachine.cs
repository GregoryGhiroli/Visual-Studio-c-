﻿/*Gregory Ghiroli
 * This program runs a stubborn vending that has no remorse for its creator
 * NACA 160.02
 * 11/13/14
 */



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace drinkVendingMachine
{
    public partial class drinkVendingMachine : Form
    {
        public drinkVendingMachine()
        {
            InitializeComponent();
        }
        //You need to make an array exact like on the board
        string[,] Soda = { {"Cola", "1.00", "20" },
                          {"Root Beer", "1.00","20"},
                          {"Lemon Lime","1.00","20"},
                          {"Grape Soda","1.50","20"},
                          {"Cream Soda","1.50","20"} };
             
                        

        double total = 0; //Accumulator for total

        //Now make a method for updating by reference the index
        private void Update(int index)
        {
            //Get the variable from string using parse
            string name = Soda[index, 0];
            double cost = double.Parse(Soda[index, 1]);
            int remaining = int.Parse(Soda[0, 2]);
         
            int remaining2 = int.Parse(Soda[1, 2]);
            int remaining3 = int.Parse(Soda[2, 2]);
            int remaining4 = int.Parse(Soda[3, 2]);
            int remaining5 = int.Parse(Soda[4, 2]);
            int left, left1,left2,left3,left4;

            if (remaining > 0 )
            {
                remaining = remaining - 1;
                left = remaining;
                Soda[index, 2] = left.ToString();
                colasRemainingLabel.Text = left.ToString();
                total += 1.00;
                totalResultLabel.Text = "$" + total.ToString(("n2"));
            }
            else
            {
                MessageBox.Show("You are out of " + name);
            }
            switch(index)
            {
                case 1:
                    if (remaining2 > 0)
                    {
                        remaining2 = remaining2 - 1;
                        left1 = remaining2;
                        Soda[1, 2] = left1.ToString();
                        rootBeersRemainingLabel.Text = left1.ToString();
                        total += 1.00;
                        totalResultLabel.Text = "$" + total.ToString(("n2"));
                    }
                    else
                    {
                        MessageBox.Show("You are out of " + name);
                    }
                    break;
                case 2:
                    if (remaining3 > 0)
                    {
                        remaining3 = remaining3 - 1;
                        left2 = remaining3;
                        Soda[2, 2] = left2.ToString();
                        lemonLimeSodasRemainingLabel.Text = left2.ToString();
                        total += 1.00;
                        totalResultLabel.Text = "$" + total.ToString(("n2"));
                    }
                    else
                    {
                        MessageBox.Show("You are out of " + name);
                    }
                    break;
                case 3:
                    if (remaining4 > 0)
                    {
                        remaining4 = remaining4 - 1;
                        left3 = remaining4;
                        Soda[3, 2] = left3.ToString();
                        grapeSodasRemainingLabel.Text = left3.ToString();
                        total += 1.50;
                        totalResultLabel.Text = "$" + total.ToString(("n2"));
                    }
                    else
                    {
                        MessageBox.Show("You are out of " + name);
                    }
                    break;
                case 4:
                    if (remaining5 > 0)
                    {
                        remaining5 = remaining5 - 1;
                        left4 = remaining5;
                        Soda[4, 2] = left4.ToString();
                        creamSodasRemainingLabel.Text = left4.ToString();
                        total += 1.50;
                        totalResultLabel.Text = "$" + total.ToString(("n2"));
                    }
                    else
                    {
                        MessageBox.Show("You are out of " + name);
                    }
                    break;
            }
        }
                  
               
                   
                           
                      
                 
        
        

            //then use switch-case because you have five labels so you need to display the remaining different
            //by displaying the remaining
            //because if you don't use that you will have this
        

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void colaPictureBox_Click(object sender, EventArgs e)
        {
            Update(0);
        }

        private void rootBeerPictureBox_Click(object sender, EventArgs e)
        {
            Update(1);
        }

        private void lemonLimePictureBox_Click(object sender, EventArgs e)
        {
            Update(2);
        }

        private void grapeSodaPictureBox_Click(object sender, EventArgs e)
        {
            Update(3);
        }

        private void creamSodaPictureBox_Click(object sender, EventArgs e)
        {
            Update(4);
        }
    }
}
