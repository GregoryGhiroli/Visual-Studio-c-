﻿/* Gregory Ghiroli
 * NACA 160.02
 * This program calculates the distance and speed for loops and while loops
 * 
 */ 



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace distanceCalculator
{
    public partial class distanceCalculator : Form
    {
        public distanceCalculator()
        {
            InitializeComponent();
        }

        private void whileButton_Click(object sender, EventArgs e)
        {
            int distance;
            int speed;
            int time;
            int count = 1;
            resultListBox.Items.Clear();
            if(int.TryParse(speedTextBox.Text, out speed))
            {
                if(int.TryParse(timeTextBox.Text, out time))
                {
                    while ( count <= time)
                    {
                        
                         distance = count * speed;
                       
                        resultListBox.Items.Add("After hour " + count + " the distance is " + distance.ToString());
                        
                        count = count + 1;
                    }
                }
                else
                {
                    MessageBox.Show(" In valid number for time");
                }
            }
            else
            {
                MessageBox.Show(" In valid number for speed");
            }
        }

        private void forButton_Click(object sender, EventArgs e)
        {
           int distance;
            int speed;
            int time;
            resultListBox.Items.Clear();
            if(int.TryParse(speedTextBox.Text, out speed))
            {
                if(int.TryParse(timeTextBox.Text, out time))
                {
            
            
            for(  int count = 1 ; count<=time; count++)
            {
                
                distance = count * speed;
                 resultListBox.Items.Add("After hour " + count + " the distance is " + distance.ToString());
                    }
                }
                else
                {
                    MessageBox.Show(" In valid number for time");
                }
            }
            else
            {
                MessageBox.Show(" In valid number for speed");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
         this.Close();
        }









        }





        }
    
