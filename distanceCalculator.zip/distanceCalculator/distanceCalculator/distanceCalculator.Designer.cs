﻿namespace distanceCalculator
{
    partial class distanceCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.whileButton = new System.Windows.Forms.Button();
            this.forButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.instructionlabel2 = new System.Windows.Forms.Label();
            this.speedTextBox = new System.Windows.Forms.TextBox();
            this.timeTextBox = new System.Windows.Forms.TextBox();
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // whileButton
            // 
            this.whileButton.Location = new System.Drawing.Point(12, 409);
            this.whileButton.Name = "whileButton";
            this.whileButton.Size = new System.Drawing.Size(75, 23);
            this.whileButton.TabIndex = 0;
            this.whileButton.Text = "While";
            this.whileButton.UseVisualStyleBackColor = true;
            this.whileButton.Click += new System.EventHandler(this.whileButton_Click);
            // 
            // forButton
            // 
            this.forButton.Location = new System.Drawing.Point(168, 409);
            this.forButton.Name = "forButton";
            this.forButton.Size = new System.Drawing.Size(75, 23);
            this.forButton.TabIndex = 1;
            this.forButton.Text = "For";
            this.forButton.UseVisualStyleBackColor = true;
            this.forButton.Click += new System.EventHandler(this.forButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(343, 409);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(52, 53);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(127, 13);
            this.instructionLabel.TabIndex = 3;
            this.instructionLabel.Text = "Vehicle Speed after MPH";
            // 
            // instructionlabel2
            // 
            this.instructionlabel2.AutoSize = true;
            this.instructionlabel2.Location = new System.Drawing.Point(52, 102);
            this.instructionlabel2.Name = "instructionlabel2";
            this.instructionlabel2.Size = new System.Drawing.Size(80, 13);
            this.instructionlabel2.TabIndex = 4;
            this.instructionlabel2.Text = "Hours Traveled";
            // 
            // speedTextBox
            // 
            this.speedTextBox.Location = new System.Drawing.Point(188, 46);
            this.speedTextBox.Name = "speedTextBox";
            this.speedTextBox.Size = new System.Drawing.Size(100, 20);
            this.speedTextBox.TabIndex = 5;
            // 
            // timeTextBox
            // 
            this.timeTextBox.Location = new System.Drawing.Point(188, 102);
            this.timeTextBox.Name = "timeTextBox";
            this.timeTextBox.Size = new System.Drawing.Size(100, 20);
            this.timeTextBox.TabIndex = 6;
            // 
            // resultListBox
            // 
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.Location = new System.Drawing.Point(105, 141);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(203, 173);
            this.resultListBox.TabIndex = 7;
            // 
            // distanceCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 454);
            this.Controls.Add(this.resultListBox);
            this.Controls.Add(this.timeTextBox);
            this.Controls.Add(this.speedTextBox);
            this.Controls.Add(this.instructionlabel2);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.forButton);
            this.Controls.Add(this.whileButton);
            this.Name = "distanceCalculator";
            this.Text = "Distance Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button whileButton;
        private System.Windows.Forms.Button forButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label instructionlabel2;
        private System.Windows.Forms.TextBox speedTextBox;
        private System.Windows.Forms.TextBox timeTextBox;
        private System.Windows.Forms.ListBox resultListBox;
    }
}

